/**
 * AI Chatbot - Powered by Gemini API
 * Integrated with Shopify Storefront API for product search and recommendations
 */

(function() {
  'use strict';

  // Configuration
  const config = window.chatbotConfig || {};
  const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent';
  const STOREFRONT_API_URL = `https://${config.shopDomain}/api/2024-01/graphql.json`;

  // DOM Elements
  let elements = {};

  // Chat State
  let chatHistory = [];
  let isLoading = false;
  let productCache = {};

  /**
   * Initialize the chatbot
   */
  function init() {
    // Get DOM elements
    elements = {
      container: document.getElementById('chatbot-container'),
      toggle: document.getElementById('chatbot-toggle'),
      drawer: document.getElementById('chatbot-drawer'),
      close: document.getElementById('chatbot-close'),
      messages: document.getElementById('chatbot-messages'),
      welcome: document.getElementById('chatbot-welcome'),
      form: document.getElementById('chatbot-form'),
      input: document.getElementById('chatbot-input-field'),
      submit: document.getElementById('chatbot-submit')
    };

    if (!elements.container) return;

    // Event Listeners
    elements.toggle.addEventListener('click', toggleChatbot);
    elements.close.addEventListener('click', closeChatbot);
    elements.form.addEventListener('submit', handleSubmit);
    elements.input.addEventListener('input', autoResize);
    elements.input.addEventListener('keydown', handleKeyDown);

    // Quick action buttons
    document.querySelectorAll('.chatbot-quick-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const message = btn.dataset.message;
        if (message) {
          elements.input.value = message;
          handleSubmit(new Event('submit'));
        }
      });
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (elements.drawer.hasAttribute('open') && 
          !elements.drawer.contains(e.target) && 
          !elements.toggle.contains(e.target)) {
        closeChatbot();
      }
    });

    // Load chat history from session
    loadChatHistory();

    console.log('AI Chatbot initialized');
  }

  /**
   * Toggle chatbot drawer
   */
  function toggleChatbot() {
    const isOpen = elements.drawer.hasAttribute('open');
    if (isOpen) {
      closeChatbot();
    } else {
      openChatbot();
    }
  }

  /**
   * Open chatbot drawer
   */
  function openChatbot() {
    elements.drawer.setAttribute('open', '');
    elements.toggle.setAttribute('aria-expanded', 'true');
    elements.input.focus();
    scrollToBottom();
  }

  /**
   * Close chatbot drawer
   */
  function closeChatbot() {
    elements.drawer.removeAttribute('open');
    elements.toggle.setAttribute('aria-expanded', 'false');
  }

  /**
   * Handle form submission
   */
  async function handleSubmit(e) {
    e.preventDefault();
    
    const message = elements.input.value.trim();
    if (!message || isLoading) return;

    // Hide welcome message
    if (elements.welcome) {
      elements.welcome.style.display = 'none';
    }

    // Add user message
    addMessage(message, 'user');
    elements.input.value = '';
    autoResize();

    // Show typing indicator
    showTypingIndicator();

    try {
      // Check if user wants products or just chatting
      const hasProductIntent = detectProductIntent(message);
      
      console.log('=== CHATBOT DEBUG ===');
      console.log('User message:', message);
      console.log('Has product intent:', hasProductIntent);
      
      let products = [];
      
      if (hasProductIntent) {
        // STEP 1: Search products FIRST with 3 second timeout
        try {
          products = await Promise.race([
            searchProducts(message),
            new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 3000))
          ]);
        } catch (err) {
          console.log('Product search timeout or error:', err.message);
          products = [];
        }
        
        console.log('Products found:', products?.length || 0);
      }
      
      // STEP 2: NOW ask Gemini with confirmed product status
      const response = await generateResponse(message, products, hasProductIntent);
      
      console.log('AI response:', response.text);
      
      // Remove typing indicator
      hideTypingIndicator();

      // Add message with or without products
      if (hasProductIntent && products && products.length > 0) {
        addMessage(response.text, 'bot', products);
      } else {
        addMessage(response.text, 'bot', null);
      }

    } catch (error) {
      console.error('Chatbot error:', error);
      hideTypingIndicator();
      addMessage('Bir hata oluştu, lütfen tekrar deneyin. / An error occurred, please try again.', 'bot');
    }

    isLoading = false;
    saveChatHistory();
  }

  /**
   * Detect language from message
   */
  function detectLanguage(message) {
    const turkishChars = /[ğüşıöçĞÜŞİÖÇ]/;
    const turkishWords = ['merhaba', 'istiyorum', 'göster', 'bana', 'var', 'öner', 'lazım', 'arıyorum', 'ne', 'nasıl'];
    const lowerMsg = message.toLowerCase();
    
    if (turkishChars.test(message)) return 'tr';
    if (turkishWords.some(w => lowerMsg.includes(w))) return 'tr';
    return 'en';
  }

  /**
   * Add message to chat
   */
  function addMessage(text, type, products = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chatbot-message chatbot-message--${type}`;

    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    avatar.innerHTML = type === 'bot' 
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';

    const content = document.createElement('div');
    content.className = 'chatbot-message__content';
    
    // Parse markdown-like formatting
    content.innerHTML = parseMessageText(text);

    // Add product cards if available
    if (products && products.length > 0) {
      console.log('Adding product cards:', products.length); // Debug
      const productsHtml = createProductCards(products);
      content.innerHTML += productsHtml;
    } else {
      console.log('No products to display'); // Debug
    }

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    elements.messages.appendChild(messageDiv);

    // Save to history
    chatHistory.push({ text, type, products, timestamp: Date.now() });

    scrollToBottom();
  }

  /**
   * Parse message text for formatting
   */
  function parseMessageText(text) {
    // Convert **bold** to <strong>
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Convert *italic* to <em>
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Convert newlines to <br>
    text = text.replace(/\n/g, '<br>');
    // Convert bullet points
    text = text.replace(/^- (.*)$/gm, '• $1');
    return text;
  }

  /**
   * Create product cards HTML
   */
  function createProductCards(products) {
    if (!products || !Array.isArray(products) || products.length === 0) {
      console.log('createProductCards: No valid products array');
      return '';
    }

    console.log('Creating cards for', products.length, 'products');

    let html = '<div class="chatbot-products">';
    
    products.forEach((product, index) => {
      if (!product || !product.handle) {
        console.log('Skipping invalid product at index', index);
        return;
      }
      
      const price = formatMoney(product.priceRange?.minVariantPrice?.amount || 0);
      
      // Handle different image URL formats
      let imageUrl = '';
      if (product.featuredImage?.url) {
        imageUrl = product.featuredImage.url;
      } else if (product.images?.edges?.[0]?.node?.url) {
        imageUrl = product.images.edges[0].node.url;
      }
      
      // Clean up image URL - remove any existing size parameters and add our own
      if (imageUrl) {
        imageUrl = imageUrl.split('?')[0]; // Remove query params
        imageUrl += '?width=280&height=280&crop=center';
      }
      
      const url = `${config.routes.root || '/'}products/${product.handle}`;
      const title = product.title || 'Product';
      
      html += `
        <a href="${url}" class="chatbot-product-card">
          ${imageUrl ? `<img src="${imageUrl}" alt="${escapeHtml(title)}" class="chatbot-product-card__image" loading="lazy" onerror="this.style.display='none'">` : '<div class="chatbot-product-card__image" style="background:#f0f0f0;"></div>'}
          <div class="chatbot-product-card__info">
            <h5 class="chatbot-product-card__title">${escapeHtml(title)}</h5>
            <span class="chatbot-product-card__price">${price}</span>
          </div>
        </a>
      `;
    });
    
    html += '</div>';
    return html;
  }

  /**
   * Show typing indicator
   */
  function showTypingIndicator() {
    isLoading = true;
    elements.submit.disabled = true;

    const indicator = document.createElement('div');
    indicator.className = 'chatbot-message chatbot-message--bot';
    indicator.id = 'chatbot-typing';
    indicator.innerHTML = `
      <div class="chatbot-message__avatar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </div>
      <div class="chatbot-typing">
        <span class="chatbot-typing__dot"></span>
        <span class="chatbot-typing__dot"></span>
        <span class="chatbot-typing__dot"></span>
      </div>
    `;

    elements.messages.appendChild(indicator);
    scrollToBottom();
  }

  /**
   * Hide typing indicator
   */
  function hideTypingIndicator() {
    isLoading = false;
    elements.submit.disabled = false;
    const indicator = document.getElementById('chatbot-typing');
    if (indicator) indicator.remove();
  }

  /**
   * Search products using Storefront API
   */
  async function searchProducts(query) {
    // Extract potential product-related keywords
    const searchTerms = extractSearchTerms(query);
    
    console.log('Search query for API:', searchTerms);

    const graphqlQuery = `
      query SearchProducts($query: String!) {
        products(first: 4, query: $query) {
          edges {
            node {
              id
              title
              handle
              description
              productType
              vendor
              tags
              priceRange {
                minVariantPrice {
                  amount
                  currencyCode
                }
                maxVariantPrice {
                  amount
                  currencyCode
                }
              }
              compareAtPriceRange {
                minVariantPrice {
                  amount
                }
              }
              featuredImage {
                url
                altText
              }
              images(first: 1) {
                edges {
                  node {
                    url
                    altText
                  }
                }
              }
              availableForSale
              totalInventory
              variants(first: 3) {
                edges {
                  node {
                    id
                    title
                    price {
                      amount
                      currencyCode
                    }
                    availableForSale
                  }
                }
              }
            }
          }
        }
      }
    `;

    try {
      const apiUrl = `https://4fee9w-bw.myshopify.com/api/2024-01/graphql.json`;
      
      console.log('Fetching from:', apiUrl);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Storefront-Access-Token': config.storefrontToken
        },
        body: JSON.stringify({
          query: graphqlQuery,
          variables: { query: searchTerms }
        })
      });

      if (!response.ok) {
        console.error('Storefront API HTTP error:', response.status);
        return [];
      }

      const data = await response.json();
      
      console.log('Storefront API response:', JSON.stringify(data, null, 2));
      
      if (data.errors) {
        console.error('Storefront API errors:', data.errors);
        return [];
      }

      const products = data.data?.products?.edges?.map(edge => edge.node) || [];
      
      console.log(`Found ${products.length} products`);
      
      // Cache products for context
      products.forEach(p => {
        productCache[p.handle] = p;
      });

      return products;
    } catch (error) {
      console.error('Product search error:', error);
      return [];
    }
  }

  /**
   * Detect if user wants to see products or just chatting
   */
  function detectProductIntent(message) {
    const lowerMessage = message.toLowerCase().trim();
    
    // Pure greetings - NO product intent
    const pureGreetings = [
      'merhaba', 'selam', 'hey', 'hi', 'hello', 'hola', 'ciao',
      'günaydın', 'gunaydin', 'iyi günler', 'iyi gunler', 'iyi akşamlar', 'iyi aksamlar',
      'good morning', 'good afternoon', 'good evening', 'nasılsın', 'nasilsin',
      'how are you', 'whats up', "what's up", 'naber', 'ne haber'
    ];
    
    // Check if message is ONLY a greeting
    if (pureGreetings.some(g => lowerMessage === g || lowerMessage === g + '!')) {
      return false;
    }
    
    // Questions without product intent
    const nonProductPhrases = [
      'nasıl yardımcı', 'nasil yardimci', 'ne yapabilirsin', 'kimsin', 'who are you',
      'how can you help', 'what can you do', 'teşekkür', 'tesekkur', 'thank', 'thanks',
      'tamam', 'ok', 'okay', 'anladım', 'anladim', 'got it', 'bye', 'güle güle', 'gule gule',
      'hoşça kal', 'hosca kal', 'görüşürüz', 'gorusuruz'
    ];
    
    if (nonProductPhrases.some(p => lowerMessage.includes(p))) {
      return false;
    }
    
    // Product-related keywords that indicate search intent
    const productKeywords = [
      // Clothing items - English
      'jacket', 'coat', 'dress', 'shirt', 'pants', 'jeans', 'skirt', 'sweater',
      'hoodie', 'blazer', 't-shirt', 'tshirt', 'blouse', 'vest', 'top', 'bottom',
      // Clothing items - Turkish
      'ceket', 'mont', 'kaban', 'elbise', 'gömlek', 'gomlek', 'pantolon', 'etek',
      'kazak', 'bluz', 'yelek', 'tişört', 'tisort', 'triko',
      // Materials
      'leather', 'deri', 'denim', 'kot', 'wool', 'yün', 'yun', 'cotton', 'pamuk',
      'silk', 'ipek', 'kürk', 'kurk', 'fur', 'suede', 'süet', 'suet',
      // Accessories - English
      'bag', 'handbag', 'purse', 'wallet', 'necklace', 'bracelet', 'ring', 'earring',
      'watch', 'belt', 'scarf', 'hat', 'cap', 'shoes', 'boots', 'sneakers', 'heels',
      // Accessories - Turkish
      'çanta', 'canta', 'cüzdan', 'cuzdan', 'kolye', 'bileklik', 'yüzük', 'yuzuk',
      'küpe', 'kupe', 'saat', 'kemer', 'şal', 'sal', 'atkı', 'atki', 'şapka', 'sapka',
      'ayakkabı', 'ayakkabi', 'bot', 'çizme', 'cizme', 'topuklu', 'bere',
      // Action words
      'göster', 'goster', 'bul', 'ara', 'öner', 'oner', 'show', 'find', 'search',
      'recommend', 'suggest', 'looking for', 'arıyorum', 'ariyorum', 'istiyorum',
      'lazım', 'lazim', 'need', 'want', 'buy', 'almak', 'satın', 'satin',
      // Categories
      'ürün', 'urun', 'product', 'products', 'collection', 'koleksiyon',
      'yeni', 'new', 'indirim', 'sale', 'popüler', 'populer', 'popular'
    ];
    
    // Check if any product keyword exists in message
    const hasProductKeyword = productKeywords.some(keyword => {
      // Check for word boundary to avoid false positives
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      return regex.test(lowerMessage);
    });
    
    return hasProductKeyword;
  }

  /**
   * Extract search terms from user message
   */
  function extractSearchTerms(message) {
    const lowerMessage = message.toLowerCase();
    
    // Comprehensive Turkish to English mapping for store products
    const searchMapping = {
      // Headwear - Turkish
      'bere': 'beanie',
      'şapka': 'hat',
      'sapka': 'hat',
      'kafa bandı': 'headband',
      'saç bandı': 'headband',
      // Outerwear - Turkish
      'deri ceket': 'leather faux jacket',
      'deri': 'leather faux',
      'ceket': 'jacket bomber biker',
      'mont': 'jacket coat bomber',
      'kaban': 'coat jacket',
      'bomber': 'bomber',
      // Knitwear - Turkish  
      'kazak': 'hoodie sweater',
      'sweatshirt': 'hoodie',
      'pullover': 'hoodie sweater',
      'hoodie': 'hoodie',
      'kapüşonlu': 'hoodie',
      'kapsonlu': 'hoodie',
      'hırka': 'cardigan',
      // Accessories - Turkish
      'kürk': 'fur faux',
      'kurk': 'fur faux',
      'atkı': 'scarf',
      'atki': 'scarf',
      'şal': 'scarf',
      'sal': 'scarf',
      // Clothing - Turkish
      'elbise': 'dress',
      'pantolon': 'pants trousers',
      'gömlek': 'shirt',
      'gomlek': 'shirt',
      // English pass-through
      'beanie': 'beanie',
      'hat': 'hat',
      'hoodie': 'hoodie',
      'jacket': 'jacket',
      'leather': 'leather faux',
      'fur': 'fur faux',
      'faux': 'faux',
      'scarf': 'scarf',
      'dress': 'dress',
      'bomber': 'bomber',
      'biker': 'biker'
    };

    // Action words to remove
    const ignoreWords = new Set([
      'istiyorum', 'göster', 'goster', 'öner', 'oner', 'bana', 'bul', 'ara',
      'var', 'mı', 'mi', 'lütfen', 'lutfen', 'için', 'icin', 'bir', 'tane',
      'want', 'show', 'find', 'me', 'please', 'some', 'the', 'a', 'need',
      'looking', 'for', 'recommend', 'suggest', 'kadın', 'kadin', 'erkek'
    ]);

    // First, check for multi-word phrases
    let searchQuery = lowerMessage;
    Object.keys(searchMapping).forEach(key => {
      if (key.includes(' ') && searchQuery.includes(key)) {
        searchQuery = searchQuery.replace(key, searchMapping[key]);
      }
    });

    // Extract words
    const words = searchQuery
      .replace(/[.,!?;:'"()]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 1 && !ignoreWords.has(word));

    // Map remaining single words
    const searchTerms = [];
    words.forEach(word => {
      if (searchMapping[word]) {
        searchTerms.push(searchMapping[word]);
      } else if (word.length > 2) {
        searchTerms.push(word);
      }
    });

    // Flatten and dedupe
    const allTerms = searchTerms.join(' ').split(' ');
    const uniqueTerms = [...new Set(allTerms)].filter(t => t.length > 1);
    
    console.log('extractSearchTerms:', lowerMessage, '->', uniqueTerms.join(' '));
    
    return uniqueTerms.length > 0 ? uniqueTerms.join(' ') : '*';
  }

  /**
   * Generate AI response using Gemini API
   * Called AFTER product search - so we know exactly if products were found
   */
  async function generateResponse(userMessage, products, hasProductIntent = false) {
    const lang = detectLanguage(userMessage);
    const foundProducts = products && products.length > 0;
    
    console.log('generateResponse - Lang:', lang, 'hasProductIntent:', hasProductIntent, 'foundProducts:', foundProducts);
    
    // Build situation context based on ACTUAL search results
    let situationContext = '';
    
    if (hasProductIntent) {
      if (foundProducts) {
        situationContext = `

DURUM: Kullanıcı ürün istedi ve ${products.length} ÜRÜN BULUNDU!
Ürün kartları mesajının altında otomatik gösterilecek.

GÖREV: KISA pozitif cevap yaz (1-2 cümle).
${lang === 'tr' ? 'Örnek: "Harika seçim! İşte sizin için bulduğum ürünler:"' : 'Example: "Great choice! Here are the products I found:"'}

KESİNLİKLE YAPMA: "bulunamadı", "yok", "maalesef", "unfortunately" kelimelerini KULLANMA - ÜRÜNLER BULUNDU!`;
      } else {
        situationContext = `

DURUM: Kullanıcı ürün istedi ama bu ürün BULUNAMADI.

GÖREV: Özür dile ve alternatif öner (bere, şapka, hoodie, atkı).
${lang === 'tr' ? 'Örnek: "Maalesef bu ürünü bulamadım. Bere veya hoodie modellerimize bakmak ister misiniz?"' : 'Example: "I could not find that product. Would you like to see our beanies or hoodies?"'}`;
      }
    }

    const recentHistory = chatHistory.slice(-6).map(msg => ({
      role: msg.type === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const systemPrompt = `Sen "${config.shopName}" mağazasının yardımcı asistanısın.

KURALLAR:
1. HER ZAMAN ${lang === 'tr' ? 'TÜRKÇE' : 'ENGLISH'} cevap ver
2. KISA cevaplar ver (1-2 cümle max)
3. Samimi ve yardımsever ol
${situationContext}`;

    const contents = [];
    if (recentHistory.length > 0) {
      recentHistory.forEach(msg => contents.push(msg));
    }
    contents.push({ role: 'user', parts: [{ text: userMessage }] });

    const requestBody = {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: contents,
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 512
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
      ]
    };

    try {
      const response = await fetch(`${GEMINI_API_URL}?key=${config.geminiApiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Gemini API error:', errorData);
        throw new Error(`Gemini API error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message);
      }

      let text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      
      // Clean up markdown links
      text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
      text = text.replace(/https?:\/\/[^\s]+/g, '');
      
      if (!text) {
        text = foundProducts 
          ? 'İşte sizin için bulduğum ürünler!' 
          : 'Merhaba! Size nasıl yardımcı olabilirim?';
      }

      return { text: text };
    } catch (error) {
      console.error('Gemini API error:', error);
      
      if (foundProducts) {
        return { text: 'İşte aradığınız ürünler!' };
      }
      return { text: 'Merhaba! Size nasıl yardımcı olabilirim?' };
    }
  }

  /**
   * Format money according to shop settings
   */
  function formatMoney(cents) {
    if (typeof cents === 'string') {
      cents = parseFloat(cents);
    }
    
    const amount = cents.toFixed(2);
    let format = config.moneyFormat || '${{amount}}';
    
    return format
      .replace('{{amount}}', amount)
      .replace('{{amount_no_decimals}}', Math.round(cents))
      .replace('{{amount_with_comma_separator}}', amount.replace('.', ','))
      .replace('{{amount_no_decimals_with_comma_separator}}', Math.round(cents).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','));
  }

  /**
   * Escape HTML to prevent XSS
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Auto-resize textarea
   */
  function autoResize() {
    elements.input.style.height = 'auto';
    elements.input.style.height = Math.min(elements.input.scrollHeight, 120) + 'px';
  }

  /**
   * Handle keyboard events
   */
  function handleKeyDown(e) {
    // Submit on Enter (without Shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(new Event('submit'));
    }
  }

  /**
   * Scroll messages to bottom
   */
  function scrollToBottom() {
    requestAnimationFrame(() => {
      elements.messages.scrollTop = elements.messages.scrollHeight;
    });
  }

  /**
   * Save chat history to session storage
   */
  function saveChatHistory() {
    try {
      const historyToSave = chatHistory.slice(-20); // Keep last 20 messages
      sessionStorage.setItem('chatbot_history', JSON.stringify(historyToSave));
    } catch (e) {
      // Session storage not available
    }
  }

  /**
   * Load chat history from session storage
   */
  function loadChatHistory() {
    try {
      const saved = sessionStorage.getItem('chatbot_history');
      if (saved) {
        const history = JSON.parse(saved);
        if (history && history.length > 0) {
          // Hide welcome message
          if (elements.welcome) {
            elements.welcome.style.display = 'none';
          }
          // Restore messages
          history.forEach(msg => {
            addMessageFromHistory(msg);
          });
          chatHistory = history;
        }
      }
    } catch (e) {
      // Session storage not available or invalid data
    }
  }

  /**
   * Add message from history (without saving again)
   */
  function addMessageFromHistory(msg) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chatbot-message chatbot-message--${msg.type}`;

    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    avatar.innerHTML = msg.type === 'bot' 
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';

    const content = document.createElement('div');
    content.className = 'chatbot-message__content';
    content.innerHTML = parseMessageText(msg.text);

    if (msg.products && msg.products.length > 0) {
      content.innerHTML += createProductCards(msg.products);
    }

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    elements.messages.appendChild(messageDiv);
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose API for external use
  window.Chatbot = {
    open: openChatbot,
    close: closeChatbot,
    toggle: toggleChatbot,
    sendMessage: (msg) => {
      elements.input.value = msg;
      handleSubmit(new Event('submit'));
    }
  };

})();
