/**
 * AI Chatbot - Powered by Gemini API
 * Integrated with Shopify Storefront API for product search and recommendations
 */

(function() {
  'use strict';

  // Configuration
  const config = window.chatbotConfig || {};
  const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent';
  const STOREFRONT_API_URL = `https://${config.shopDomain}/api/2024-01/graphql.json`;

  // DOM Elements
  let elements = {};

  // Chat State
  let chatHistory = [];
  let isLoading = false;
  let productCache = {};
  let currentLanguage = null; // Will be set from site language on init
  let lastSearchQuery = '';   // Context for follow-up questions
  let lastProductShown = false; // Did we show products recently?

  /**
   * Initialize the chatbot
   */
  function init() {
    // Get DOM elements
    elements = {
      container: document.getElementById('chatbot-container'),
      toggle: document.getElementById('chatbot-toggle'),
      drawer: document.getElementById('chatbot-drawer'),
      close: document.getElementById('chatbot-close'),
      messages: document.getElementById('chatbot-messages'),
      welcome: document.getElementById('chatbot-welcome'),
      form: document.getElementById('chatbot-form'),
      input: document.getElementById('chatbot-input-field'),
      submit: document.getElementById('chatbot-submit')
    };

    if (!elements.container) return;

    // Event Listeners
    elements.toggle.addEventListener('click', toggleChatbot);
    elements.close.addEventListener('click', closeChatbot);
    elements.form.addEventListener('submit', handleSubmit);
    elements.input.addEventListener('input', autoResize);
    elements.input.addEventListener('keydown', handleKeyDown);

    // Quick action buttons
    document.querySelectorAll('.chatbot-quick-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const message = btn.dataset.message;
        if (message) {
          elements.input.value = message;
          handleSubmit(new Event('submit'));
        }
      });
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (elements.drawer.hasAttribute('open') && 
          !elements.drawer.contains(e.target) && 
          !elements.toggle.contains(e.target)) {
        closeChatbot();
      }
    });

    // Load chat history from session
    loadChatHistory();

    // Initialize current language from site language
    currentLanguage = getSiteLanguage();
    console.log('Chatbot language initialized to:', currentLanguage);

    // Initialize cart notification listener
    initCartNotification();

    console.log('AI Chatbot initialized');
  }

  /**
   * Toggle chatbot drawer
   */
  function toggleChatbot() {
    const isOpen = elements.drawer.hasAttribute('open');
    if (isOpen) {
      closeChatbot();
    } else {
      openChatbot();
    }
  }

  // Track if welcome message has been shown
  let welcomeShown = false;
  let originalHeaderText = null;

  /**
   * Open chatbot drawer
   */
  function openChatbot() {
    elements.drawer.setAttribute('open', '');
    elements.toggle.setAttribute('aria-expanded', 'true');
    elements.input.focus();
    
    // Hide notification badge when opening
    const badge = document.getElementById('chatbot-badge');
    if (badge) {
      badge.classList.remove('active');
    }
    
    // Change site header text to "Shopping Assistant"
    const headerTextEl = document.querySelector('.header__menu-text--auto, .header__menu-text');
    if (headerTextEl) {
      originalHeaderText = headerTextEl.textContent;
      headerTextEl.textContent = 'Shopping Assistant';
    }
    
    // Check for pending cart notification
    const pendingItem = sessionStorage.getItem('pendingCartItem');
    if (pendingItem) {
      sessionStorage.removeItem('pendingCartItem');
      setTimeout(() => {
        sendCartNotificationMessage(JSON.parse(pendingItem));
      }, 300);
      welcomeShown = true; // Skip welcome message if we have a cart notification
    }
    // Show welcome message on first open
    else if (!welcomeShown && chatHistory.length === 0) {
      welcomeShown = true;
      setTimeout(() => {
        showWelcomeMessages();
      }, 300);
    } else {
      scrollToBottom();
    }
  }

  /**
   * Get current site language from Shopify
   */
  function getSiteLanguage() {
    // Check Shopify locale
    if (window.Shopify && window.Shopify.locale) {
      const locale = window.Shopify.locale.toLowerCase();
      if (locale.startsWith('de')) return 'de';
      if (locale.startsWith('fr')) return 'fr';
      if (locale.startsWith('es')) return 'es';
      if (locale.startsWith('it')) return 'it';
      if (locale.startsWith('tr')) return 'tr';
      if (locale.startsWith('nl')) return 'nl';
      if (locale.startsWith('ja')) return 'ja';
      if (locale.startsWith('ar')) return 'ar';
      if (locale.startsWith('pt')) return 'pt';
      if (locale.startsWith('pl')) return 'pl';
      if (locale.startsWith('sv')) return 'sv';
      if (locale.startsWith('nb') || locale.startsWith('no')) return 'nb';
      if (locale.startsWith('fi')) return 'fi';
      return 'en';
    }
    
    // Check HTML lang attribute
    const htmlLang = document.documentElement.lang;
    if (htmlLang) {
      const lang = htmlLang.toLowerCase().substring(0, 2);
      if (['de', 'fr', 'es', 'it', 'tr', 'nl', 'ja', 'ar', 'pt', 'pl', 'sv', 'nb', 'fi'].includes(lang)) {
        return lang;
      }
    }
    
    return 'en';
  }

  /**
   * Get chatbot UI texts based on language
   */
  function getChatbotTexts(lang) {
    const texts = {
      tr: {
        welcome: 'Merhaba! 👋 Ben alışveriş asistanınızım. Size ürün bulmada, sorularınızı yanıtlamada ve alışverişinizde yardımcı olabilirim.',
        howCanIHelp: 'Size nasıl yardımcı olabilirim?',
        popularProducts: 'Popüler ürünler',
        onSale: 'İndirimde',
        findProduct: 'Ürün bul',
        popularProductsMsg: 'Popüler ürünleri göster',
        onSaleMsg: 'İndirimli ürünler neler?',
        findProductMsg: 'Bir şey bulmama yardım et',
        inputPlaceholder: 'Mesajınızı yazın...'
      },
      en: {
        welcome: 'Hello! 👋 I\'m your shopping assistant. I can help you find products, answer your questions, and assist with your shopping.',
        howCanIHelp: 'How can I help you?',
        popularProducts: 'Popular products',
        onSale: 'On sale',
        findProduct: 'Find product',
        popularProductsMsg: 'Show popular products',
        onSaleMsg: 'What products are on sale?',
        findProductMsg: 'Help me find something',
        inputPlaceholder: 'Type your message...'
      },
      de: {
        welcome: 'Hallo! 👋 Ich bin Ihr Einkaufsassistent. Ich kann Ihnen helfen, Produkte zu finden, Ihre Fragen zu beantworten und Sie beim Einkaufen zu unterstützen.',
        howCanIHelp: 'Wie kann ich Ihnen helfen?',
        popularProducts: 'Beliebte Produkte',
        onSale: 'Im Angebot',
        findProduct: 'Produkt finden',
        popularProductsMsg: 'Zeige beliebte Produkte',
        onSaleMsg: 'Welche Produkte sind im Angebot?',
        findProductMsg: 'Hilf mir etwas zu finden',
        inputPlaceholder: 'Nachricht eingeben...'
      },
      fr: {
        welcome: 'Bonjour! 👋 Je suis votre assistant shopping. Je peux vous aider à trouver des produits, répondre à vos questions et vous accompagner dans vos achats.',
        howCanIHelp: 'Comment puis-je vous aider?',
        popularProducts: 'Produits populaires',
        onSale: 'En promotion',
        findProduct: 'Trouver un produit',
        popularProductsMsg: 'Montre les produits populaires',
        onSaleMsg: 'Quels produits sont en promotion?',
        findProductMsg: 'Aide-moi à trouver quelque chose',
        inputPlaceholder: 'Écrivez votre message...'
      },
      es: {
        welcome: '¡Hola! 👋 Soy tu asistente de compras. Puedo ayudarte a encontrar productos, responder tus preguntas y asistirte en tus compras.',
        howCanIHelp: '¿Cómo puedo ayudarte?',
        popularProducts: 'Productos populares',
        onSale: 'En oferta',
        findProduct: 'Buscar producto',
        popularProductsMsg: 'Muestra productos populares',
        onSaleMsg: '¿Qué productos están en oferta?',
        findProductMsg: 'Ayúdame a encontrar algo',
        inputPlaceholder: 'Escribe tu mensaje...'
      },
      it: {
        welcome: 'Ciao! 👋 Sono il tuo assistente per lo shopping. Posso aiutarti a trovare prodotti, rispondere alle tue domande e assisterti nei tuoi acquisti.',
        howCanIHelp: 'Come posso aiutarti?',
        popularProducts: 'Prodotti popolari',
        onSale: 'In offerta',
        findProduct: 'Trova prodotto',
        popularProductsMsg: 'Mostra prodotti popolari',
        onSaleMsg: 'Quali prodotti sono in offerta?',
        findProductMsg: 'Aiutami a trovare qualcosa',
        inputPlaceholder: 'Scrivi il tuo messaggio...'
      },
      nl: {
        welcome: 'Hallo! 👋 Ik ben je shopping assistent. Ik kan je helpen producten te vinden, je vragen beantwoorden en je helpen bij het winkelen.',
        howCanIHelp: 'Hoe kan ik je helpen?',
        popularProducts: 'Populaire producten',
        onSale: 'In de aanbieding',
        findProduct: 'Product zoeken',
        popularProductsMsg: 'Toon populaire producten',
        onSaleMsg: 'Welke producten zijn in de aanbieding?',
        findProductMsg: 'Help me iets te vinden',
        inputPlaceholder: 'Typ je bericht...'
      },
      ja: {
        welcome: 'こんにちは！👋 私はあなたのショッピングアシスタントです。商品検索、ご質問への回答、お買い物のお手伝いをします。',
        howCanIHelp: 'どのようにお手伝いしましょうか？',
        popularProducts: '人気商品',
        onSale: 'セール中',
        findProduct: '商品を探す',
        popularProductsMsg: '人気商品を見せて',
        onSaleMsg: 'セール中の商品は？',
        findProductMsg: '探し物を手伝って',
        inputPlaceholder: 'メッセージを入力...'
      },
      ar: {
        welcome: 'مرحباً! 👋 أنا مساعد التسوق الخاص بك. يمكنني مساعدتك في العثور على المنتجات والإجابة على أسئلتك ومساعدتك في التسوق.',
        howCanIHelp: 'كيف يمكنني مساعدتك؟',
        popularProducts: 'منتجات شائعة',
        onSale: 'عروض',
        findProduct: 'البحث عن منتج',
        popularProductsMsg: 'أظهر المنتجات الشائعة',
        onSaleMsg: 'ما هي المنتجات المعروضة؟',
        findProductMsg: 'ساعدني في إيجاد شيء',
        inputPlaceholder: 'اكتب رسالتك...'
      },
      pt: {
        welcome: 'Olá! 👋 Sou seu assistente de compras. Posso ajudá-lo a encontrar produtos, responder suas perguntas e auxiliar nas suas compras.',
        howCanIHelp: 'Como posso ajudá-lo?',
        popularProducts: 'Produtos populares',
        onSale: 'Em promoção',
        findProduct: 'Encontrar produto',
        popularProductsMsg: 'Mostre produtos populares',
        onSaleMsg: 'Quais produtos estão em promoção?',
        findProductMsg: 'Me ajude a encontrar algo',
        inputPlaceholder: 'Digite sua mensagem...'
      }
    };
    
    return texts[lang] || texts['en'];
  }

  /**
   * Show welcome messages as bot messages
   */
  function showWelcomeMessages() {
    const lang = getSiteLanguage();
    const texts = getChatbotTexts(lang);
    
    addMessage(texts.welcome, 'bot');
    
    // Update input placeholder
    if (elements.input) {
      elements.input.placeholder = texts.inputPlaceholder;
    }
    
    // Add quick action buttons after welcome
    setTimeout(() => {
      addQuickActions();
    }, 500);
  }

  /**
   * Add quick action buttons as a message
   */
  function addQuickActions() {
    const lang = getSiteLanguage();
    const texts = getChatbotTexts(lang);
    
    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'chatbot-message chatbot-message--bot';
    actionsDiv.innerHTML = `
      <div class="chatbot-message__avatar">
        <canvas width="64" height="64"></canvas>
      </div>
      <div class="chatbot-message__content">
        <p style="margin-bottom: 12px;">${texts.howCanIHelp}</p>
        <div class="chatbot-quick-actions">
          <button type="button" class="chatbot-quick-action" data-message="${texts.popularProductsMsg}">${texts.popularProducts}</button>
          <button type="button" class="chatbot-quick-action" data-message="${texts.onSaleMsg}">${texts.onSale}</button>
          <button type="button" class="chatbot-quick-action" data-message="${texts.findProductMsg}">${texts.findProduct}</button>
        </div>
      </div>
    `;
    
    // Draw mini face on canvas
    const canvas = actionsDiv.querySelector('canvas');
    if (canvas) {
      const ctx = canvas.getContext('2d');
      drawMiniFace(ctx, 'happy');
    }
    
    elements.messages.appendChild(actionsDiv);
    
    // Add click handlers for quick actions
    actionsDiv.querySelectorAll('.chatbot-quick-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const message = btn.dataset.message;
        if (message) {
          elements.input.value = message;
          handleSubmit(new Event('submit'));
        }
      });
    });
    
    scrollToBottom();
  }

  /**
   * Close chatbot drawer
   */
  function closeChatbot() {
    elements.drawer.removeAttribute('open');
    elements.toggle.setAttribute('aria-expanded', 'false');
    
    // Restore original header text
    if (originalHeaderText !== null) {
      const headerTextEl = document.querySelector('.header__menu-text--auto, .header__menu-text');
      if (headerTextEl) {
        headerTextEl.textContent = originalHeaderText;
      }
    }
  }

  /**
   * Handle form submission
   */
  async function handleSubmit(e) {
    e.preventDefault();
    
    const message = elements.input.value.trim();
    if (!message || isLoading) return;

    // Add user message
    addMessage(message, 'user');
    elements.input.value = '';
    autoResize();

    // Show typing indicator
    showTypingIndicator();

    try {
      // 1. Detect and update language
      detectLanguage(message);
      
      // 2. Check if user wants products OR is confirming a previous suggestion
      let hasProductIntent = detectProductIntent(message);
      let searchContext = message;

      // Logic for "Yes/Farketmez" flows
      const confirmationKeywords = ['evet', 'yes', 'tamam', 'ok', 'olur', 'farketmez', 'tabi', 'lütfen', 'please', 'göster', 'show'];
      const isConfirmation = confirmationKeywords.some(w => message.toLowerCase().includes(w));
      
      if (isConfirmation && lastSearchQuery && !hasProductIntent) {
        console.log('Confirmation detected, using last context:', lastSearchQuery);
        hasProductIntent = true;
        searchContext = lastSearchQuery + ' ' + message; // Combine contexts
      }
      
      console.log('=== CHATBOT DEBUG ===');
      console.log('User message:', message);
      console.log('Current Lang:', currentLanguage);
      console.log('Has product intent:', hasProductIntent);
      console.log('Last Search Query:', lastSearchQuery);
      
      let products = [];
      
      if (hasProductIntent) {
        // Update last search query if this looks like a NEW search
        const extractedTerms = extractSearchTerms(message);
        
        // If we found valid search terms (longer than a single character wildcard)
        if (extractedTerms !== '*' && extractedTerms.length > 2) {
           lastSearchQuery = message; 
           searchContext = message;
        } else if ((isConfirmation || extractedTerms === '*') && lastSearchQuery) {
           // Fallback to last successful query if current query is empty or just confirmation
           console.log('Using last search query for context:', lastSearchQuery);
           searchContext = lastSearchQuery;
        }

        // STEP 1: Search products FIRST with 3 second timeout
        try {
          products = await Promise.race([
            searchProducts(searchContext),
            new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 3000))
          ]);
        } catch (err) {
          console.log('Product search timeout or error:', err.message);
          products = [];
        }
        
        console.log('Products found:', products?.length || 0);
        lastProductShown = products && products.length > 0;
      } else {
        lastProductShown = false;
      }
      
      // STEP 2: NOW ask Gemini with confirmed product status
      const response = await generateResponse(message, products, hasProductIntent);
      
      console.log('AI response:', response.text);
      
      // Remove typing indicator
      hideTypingIndicator();

      // Add message with or without products
      if (hasProductIntent && products && products.length > 0) {
        addMessage(response.text, 'bot', products);
      } else {
        addMessage(response.text, 'bot', null);
      }

    } catch (error) {
      console.error('Chatbot error:', error);
      hideTypingIndicator();
      addMessage('Bir hata oluştu, lütfen tekrar deneyin. / An error occurred, please try again.', 'bot');
    }

    isLoading = false;
    saveChatHistory();
  }

  /**
   * Get language name for system prompt
   */
  function getLanguageName(langCode) {
    const names = {
      'tr': 'TÜRKÇE',
      'en': 'ENGLISH',
      'de': 'DEUTSCH (German)',
      'fr': 'FRANÇAIS (French)',
      'es': 'ESPAÑOL (Spanish)',
      'it': 'ITALIANO (Italian)',
      'nl': 'NEDERLANDS (Dutch)',
      'ja': '日本語 (Japanese)',
      'ar': 'العربية (Arabic)',
      'pt': 'PORTUGUÊS (Portuguese)',
      'pl': 'POLSKI (Polish)',
      'sv': 'SVENSKA (Swedish)',
      'nb': 'NORSK (Norwegian)',
      'fi': 'SUOMI (Finnish)'
    };
    return names[langCode] || 'ENGLISH';
  }

  /**
   * Detect language from user message - but respect site language as default
   */
  function detectLanguage(message) {
    const lowerMsg = message.toLowerCase();
    
    // Turkish signals
    const turkishChars = /[ğüşıöçĞÜŞİÖÇ]/;
    const turkishWords = ['merhaba', 'istiyorum', 'göster', 'bana', 'var', 'öner', 'lazım', 'arıyorum', 'ne', 'nasıl', 'evet', 'hayır', 'tamam', 'teşekkür'];
    if (turkishChars.test(message) || turkishWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'tr';
      return 'tr';
    }
    
    // German signals
    const germanChars = /[äöüßÄÖÜ]/;
    const germanWords = ['hallo', 'ich', 'möchte', 'zeigen', 'bitte', 'danke', 'ja', 'nein', 'suche', 'brauche', 'haben', 'gibt', 'welche', 'produkte', 'angebot'];
    if (germanChars.test(message) || germanWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'de';
      return 'de';
    }
    
    // French signals
    const frenchChars = /[éèêëàâçîïôùûœæÉÈÊËÀÂÇÎÏÔÙÛŒÆ]/;
    const frenchWords = ['bonjour', 'salut', 'je', 'voudrais', 'montrer', 'merci', 'oui', 'non', 'cherche', 'produits', 'offre'];
    if (frenchChars.test(message) || frenchWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'fr';
      return 'fr';
    }
    
    // Spanish signals
    const spanishChars = /[ñáéíóúüÑÁÉÍÓÚÜ¿¡]/;
    const spanishWords = ['hola', 'quiero', 'mostrar', 'gracias', 'sí', 'busco', 'necesito', 'productos', 'oferta'];
    if (spanishChars.test(message) || spanishWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'es';
      return 'es';
    }
    
    // Italian signals
    const italianWords = ['ciao', 'voglio', 'mostrare', 'grazie', 'cerco', 'prodotti', 'offerta'];
    if (italianWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'it';
      return 'it';
    }
    
    // Dutch signals
    const dutchWords = ['hallo', 'ik', 'wil', 'tonen', 'dank', 'zoek', 'producten', 'aanbieding'];
    if (dutchWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'nl';
      return 'nl';
    }
    
    // English signals - only change if explicit English is detected
    const englishWords = ['hello', 'want', 'show me', 'need', 'thanks', 'looking for', 'find', 'products', 'sale', 'please'];
    if (englishWords.some(w => lowerMsg.includes(w))) {
      currentLanguage = 'en';
      return 'en';
    }

    // If no language detected, keep the current/site language (don't change it)
    return currentLanguage;
  }

  /**
   * Determine mood based on message content and products
   */
  function determineMood(text, products) {
    const lowerText = text.toLowerCase();
    
    // Check for product results
    if (products && products.length > 0) {
      // Many products = excited
      if (products.length >= 4) return 'excited';
      // Some products = happy
      return 'happy';
    }
    
    // Check for love/heart related words
    const loveWords = ['❤', '💕', 'seviyorum', 'harika', 'süper', 'mükemmel', 'love', 'amazing', 'perfect', 'wonderful', 'awesome'];
    if (loveWords.some(w => lowerText.includes(w))) return 'love';
    
    // Check for excited words
    const excitedWords = ['🎉', '!', 'vay', 'wow', 'heyecan', 'excited', 'great', 'yay', 'muhteşem'];
    if (excitedWords.some(w => lowerText.includes(w))) return 'excited';
    
    // Check for happy words
    const happyWords = ['teşekkür', 'sağol', 'güzel', 'iyi', 'thanks', 'thank', 'good', 'nice', 'happy', 'yardımcı', 'buldum', 'found'];
    if (happyWords.some(w => lowerText.includes(w))) return 'happy';
    
    // Check for sad/sorry words
    const sadWords = ['üzgün', 'maalesef', 'sorry', 'unfortunately', 'bulamadım', 'yok', 'not found', 'couldn\'t find', 'apologize'];
    if (sadWords.some(w => lowerText.includes(w))) return 'sad';
    
    // Check for thinking/processing words
    const thinkingWords = ['düşün', 'hmm', 'belki', 'maybe', 'think', 'consider', 'bakıyorum', 'arıyorum', 'searching'];
    if (thinkingWords.some(w => lowerText.includes(w))) return 'thinking';
    
    // Check for surprised words
    const surprisedWords = ['gerçekten', 'really', 'serious', '?!', 'şaşır', 'surprised', 'unexpected'];
    if (surprisedWords.some(w => lowerText.includes(w))) return 'surprised';
    
    // Check for greeting - friendly neutral
    const greetingWords = ['merhaba', 'selam', 'hello', 'hi', 'hey', 'hoş geldin', 'welcome'];
    if (greetingWords.some(w => lowerText.includes(w))) return 'happy';
    
    // Default neutral
    return 'neutral';
  }

  /**
   * Add message to chat with typewriter effect for bot messages
   */
  function addMessage(text, type, products = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chatbot-message chatbot-message--${type}`;

    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    
    // Determine mood based on message content and products
    const mood = determineMood(text, products);
    
    if (type === 'bot') {
      // Create mini canvas face for bot avatar
      const miniCanvas = document.createElement('canvas');
      miniCanvas.width = 64;
      miniCanvas.height = 64;
      avatar.appendChild(miniCanvas);
      
      // Draw face on mini canvas
      const ctx = miniCanvas.getContext('2d');
      drawMiniFace(ctx, mood);
    } else {
      avatar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    }

    const content = document.createElement('div');
    content.className = 'chatbot-message__content';

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    elements.messages.appendChild(messageDiv);

    // Set header avatar mood based on result
    if (type === 'bot' && window.ChatbotCanvas && window.ChatbotCanvas.setMood) {
      window.ChatbotCanvas.setMood(mood);
      
      // Effects based on mood
      if (mood === 'happy' || mood === 'excited' || mood === 'love') {
        if (window.ChatbotCanvas.sparkle) {
          const rect = messageDiv.getBoundingClientRect();
          const drawerRect = elements.drawer.getBoundingClientRect();
          window.ChatbotCanvas.sparkle(rect.left - drawerRect.left + 50, rect.top - drawerRect.top + 20);
        }
        if (mood === 'excited' && window.ChatbotCanvas.confetti) {
          window.ChatbotCanvas.confetti();
        }
      }
    }

    // Typewriter effect for bot messages
    if (type === 'bot') {
      typewriterEffect(content, text, products);
    } else {
      // User messages appear instantly
      content.innerHTML = parseMessageText(text);
    }

    // Save to history
    chatHistory.push({ text, type, products, timestamp: Date.now() });

    scrollToBottom();
  }

  /**
   * Draw mini face on canvas for message avatar - Advanced version
   */
  function drawMiniFace(ctx, mood = 'neutral') {
    const size = 64;
    const cx = 32, cy = 32;
    ctx.clearRect(0, 0, size, size);

    // Background circle with gradient
    const gradient = ctx.createRadialGradient(28, 28, 0, cx, cy, 28);
    gradient.addColorStop(0, '#333');
    gradient.addColorStop(1, '#000');
    ctx.beginPath();
    ctx.arc(cx, cy, 28, 0, Math.PI * 2);
    ctx.fillStyle = gradient;
    ctx.fill();

    // Blush cheeks for happy/love moods
    if (mood === 'happy' || mood === 'love' || mood === 'excited') {
      ctx.globalAlpha = 0.4;
      ctx.fillStyle = '#ff6b6b';
      ctx.beginPath();
      ctx.ellipse(14, 38, 6, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(50, 38, 6, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';

    // Eyebrows
    let leftBrowY = 18, rightBrowY = 18;
    if (mood === 'sad') {
      // Sad eyebrows - angled down on outer edges
      ctx.beginPath();
      ctx.moveTo(14, 16);
      ctx.lineTo(24, 19);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(50, 16);
      ctx.lineTo(40, 19);
      ctx.stroke();
    } else if (mood === 'surprised' || mood === 'excited') {
      // Raised eyebrows
      ctx.beginPath();
      ctx.moveTo(14, 14);
      ctx.lineTo(24, 14);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(40, 14);
      ctx.lineTo(50, 14);
      ctx.stroke();
    } else if (mood === 'thinking') {
      // One raised eyebrow
      ctx.beginPath();
      ctx.moveTo(14, 15);
      ctx.lineTo(24, 18);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(40, 18);
      ctx.lineTo(50, 18);
      ctx.stroke();
    } else {
      // Normal eyebrows
      ctx.beginPath();
      ctx.moveTo(14, 18);
      ctx.lineTo(24, 18);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(40, 18);
      ctx.lineTo(50, 18);
      ctx.stroke();
    }

    // Eyes
    const eyeHeight = mood === 'surprised' ? 8 : (mood === 'sleepy' ? 3 : 6);
    const eyeWidth = mood === 'surprised' ? 7 : 5;
    
    // Left eye
    ctx.beginPath();
    ctx.ellipse(19, 26, eyeWidth, eyeHeight, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Right eye
    ctx.beginPath();
    ctx.ellipse(45, 26, eyeWidth, eyeHeight, 0, 0, Math.PI * 2);
    ctx.fill();

    // Pupils (not for love or sleepy)
    if (mood !== 'love' && mood !== 'sleepy') {
      ctx.fillStyle = '#000';
      const pupilSize = mood === 'surprised' ? 3 : 2;
      ctx.beginPath();
      ctx.arc(19, 26, pupilSize, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(45, 26, pupilSize, 0, Math.PI * 2);
      ctx.fill();

      // Eye shine
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.beginPath();
      ctx.arc(17, 24, 1.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(43, 24, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Heart eyes for love mood
    if (mood === 'love') {
      ctx.fillStyle = '#ff4757';
      drawMiniHeart(ctx, 19, 26, 5);
      drawMiniHeart(ctx, 45, 26, 5);
    }

    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2.5;

    // Mouth based on mood
    if (mood === 'happy' || mood === 'love') {
      // Big smile
      ctx.beginPath();
      ctx.arc(cx, 40, 10, 0.1 * Math.PI, 0.9 * Math.PI);
      ctx.stroke();
    } else if (mood === 'excited') {
      // Open smile
      ctx.beginPath();
      ctx.ellipse(cx, 42, 8, 6, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#ff6b6b';
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillRect(26, 40, 12, 3);
    } else if (mood === 'sad') {
      // Frown
      ctx.beginPath();
      ctx.arc(cx, 50, 8, 1.2 * Math.PI, 1.8 * Math.PI);
      ctx.stroke();
    } else if (mood === 'surprised') {
      // O mouth
      ctx.beginPath();
      ctx.ellipse(cx, 44, 5, 7, 0, 0, Math.PI * 2);
      ctx.stroke();
    } else if (mood === 'thinking') {
      // Side squiggle
      ctx.beginPath();
      ctx.moveTo(28, 44);
      ctx.quadraticCurveTo(32, 42, 36, 44);
      ctx.quadraticCurveTo(40, 46, 44, 44);
      ctx.stroke();
    } else if (mood === 'sleepy') {
      // Wavy line
      ctx.beginPath();
      ctx.moveTo(26, 44);
      ctx.lineTo(38, 44);
      ctx.stroke();
    } else {
      // Neutral - small smile
      ctx.beginPath();
      ctx.arc(cx, 42, 6, 0.1 * Math.PI, 0.9 * Math.PI);
      ctx.stroke();
    }

    // Extra decorations
    // Sparkles for excited/love
    if (mood === 'excited' || mood === 'love') {
      ctx.fillStyle = '#FFD700';
      ctx.globalAlpha = 0.8;
      drawMiniSparkle(ctx, 8, 12, 3);
      drawMiniSparkle(ctx, 56, 14, 2.5);
      drawMiniSparkle(ctx, 52, 52, 2);
      ctx.globalAlpha = 1;
    }

    // Sweat drop for thinking
    if (mood === 'thinking') {
      ctx.fillStyle = '#87CEEB';
      ctx.beginPath();
      ctx.moveTo(52, 16);
      ctx.quadraticCurveTo(55, 20, 52, 24);
      ctx.quadraticCurveTo(49, 20, 52, 16);
      ctx.fill();
    }

    // ZZZ for sleepy
    if (mood === 'sleepy') {
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 8px Arial';
      ctx.fillText('Z', 50, 14);
      ctx.font = 'bold 6px Arial';
      ctx.fillText('z', 54, 10);
    }
  }

  /**
   * Draw mini heart helper
   */
  function drawMiniHeart(ctx, x, y, size) {
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.moveTo(0, size * 0.3);
    ctx.bezierCurveTo(-size * 0.5, -size * 0.3, -size, size * 0.3, 0, size);
    ctx.bezierCurveTo(size, size * 0.3, size * 0.5, -size * 0.3, 0, size * 0.3);
    ctx.fill();
    ctx.restore();
  }

  /**
   * Draw mini sparkle helper
   */
  function drawMiniSparkle(ctx, x, y, size) {
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x + size * 0.3, y);
    ctx.lineTo(x, y + size);
    ctx.lineTo(x - size * 0.3, y);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x - size, y);
    ctx.lineTo(x, y + size * 0.3);
    ctx.lineTo(x + size, y);
    ctx.lineTo(x, y - size * 0.3);
    ctx.closePath();
    ctx.fill();
  }

  /**
   * Typewriter effect for bot messages
   */
  function typewriterEffect(element, text, products) {
    const parsedText = parseMessageText(text);
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = parsedText;
    const plainText = tempDiv.textContent || tempDiv.innerText;
    
    let index = 0;
    const speed = 20; // ms per character
    
    element.innerHTML = '<span class="typewriter-cursor">|</span>';
    
    function type() {
      if (index < plainText.length) {
        const currentText = plainText.substring(0, index + 1);
        element.innerHTML = currentText + '<span class="typewriter-cursor">|</span>';
        index++;
        scrollToBottom();
        setTimeout(type, speed);
      } else {
        // Typing complete - show full formatted text
        element.innerHTML = parsedText;
        
        // Add product cards if available
        if (products && products.length > 0) {
          const productsHtml = createProductCards(products);
          element.innerHTML += productsHtml;
          
          // Confetti for products!
          if (window.ChatbotCanvas && window.ChatbotCanvas.confetti) {
            setTimeout(() => window.ChatbotCanvas.confetti(), 200);
          }
        }
        
        scrollToBottom();
      }
    }
    
    type();
  }

  /**
   * Parse message text for formatting
   */
  function parseMessageText(text) {
    // Convert **bold** to <strong>
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Convert *italic* to <em>
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Convert newlines to <br>
    text = text.replace(/\n/g, '<br>');
    // Convert bullet points
    text = text.replace(/^- (.*)$/gm, '• $1');
    return text;
  }

  /**
   * Create product cards HTML
   */
  function createProductCards(products) {
    if (!products || !Array.isArray(products) || products.length === 0) {
      console.log('createProductCards: No valid products array');
      return '';
    }

    console.log('Creating cards for', products.length, 'products');

    let html = '<div class="chatbot-products">';
    
    products.forEach((product, index) => {
      if (!product || !product.handle) {
        console.log('Skipping invalid product at index', index);
        return;
      }
      
      const price = formatMoney(product.priceRange?.minVariantPrice?.amount || 0);
      
      // Handle different image URL formats
      let imageUrl = '';
      if (product.featuredImage?.url) {
        imageUrl = product.featuredImage.url;
      } else if (product.images?.edges?.[0]?.node?.url) {
        imageUrl = product.images.edges[0].node.url;
      }
      
      // Clean up image URL - remove any existing size parameters and add our own
      if (imageUrl) {
        imageUrl = imageUrl.split('?')[0]; // Remove query params
        imageUrl += '?width=280&height=280&crop=center';
      }
      
      const url = `${config.routes.root || '/'}products/${product.handle}`;
      const title = product.title || 'Product';
      
      html += `
        <a href="${url}" class="chatbot-product-card">
          ${imageUrl ? `<img src="${imageUrl}" alt="${escapeHtml(title)}" class="chatbot-product-card__image" loading="lazy" onerror="this.style.display='none'">` : '<div class="chatbot-product-card__image" style="background:#f0f0f0;"></div>'}
          <div class="chatbot-product-card__info">
            <h5 class="chatbot-product-card__title">${escapeHtml(title)}</h5>
            <span class="chatbot-product-card__price">${price}</span>
          </div>
        </a>
      `;
    });
    
    html += '</div>';
    return html;
  }

  /**
   * Show typing indicator
   */
  function showTypingIndicator() {
    isLoading = true;
    elements.submit.disabled = true;

    // Set avatar to thinking mode
    if (window.ChatbotCanvas && window.ChatbotCanvas.setMood) {
      window.ChatbotCanvas.setMood('thinking');
    }

    const indicator = document.createElement('div');
    indicator.className = 'chatbot-message chatbot-message--bot';
    indicator.id = 'chatbot-typing';
    
    // Create typing indicator with canvas face
    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    
    // Mini canvas with thinking face
    const miniCanvas = document.createElement('canvas');
    miniCanvas.width = 64;
    miniCanvas.height = 64;
    avatar.appendChild(miniCanvas);
    const ctx = miniCanvas.getContext('2d');
    drawMiniFace(ctx, 'thinking');
    
    const typingDots = document.createElement('div');
    typingDots.className = 'chatbot-typing';
    typingDots.innerHTML = `
      <span class="chatbot-typing__dot"></span>
      <span class="chatbot-typing__dot"></span>
      <span class="chatbot-typing__dot"></span>
    `;
    
    indicator.appendChild(avatar);
    indicator.appendChild(typingDots);

    elements.messages.appendChild(indicator);
    scrollToBottom();
  }

  /**
   * Hide typing indicator
   */
  function hideTypingIndicator() {
    isLoading = false;
    elements.submit.disabled = false;
    const indicator = document.getElementById('chatbot-typing');
    if (indicator) indicator.remove();
    
    // Reset avatar mood
    if (window.ChatbotCanvas && window.ChatbotCanvas.setMood) {
      window.ChatbotCanvas.setMood('neutral');
    }
  }

  /**
   * Search products using Storefront API
   */
  async function searchProducts(query) {
    // Extract potential product-related keywords
    const searchTerms = extractSearchTerms(query);
    
    console.log('Search query for API:', searchTerms);

    const graphqlQuery = `
      query SearchProducts($query: String!) {
        products(first: 4, query: $query) {
          edges {
            node {
              id
              title
              handle
              description
              productType
              vendor
              tags
              priceRange {
                minVariantPrice {
                  amount
                  currencyCode
                }
                maxVariantPrice {
                  amount
                  currencyCode
                }
              }
              compareAtPriceRange {
                minVariantPrice {
                  amount
                }
              }
              featuredImage {
                url
                altText
              }
              images(first: 1) {
                edges {
                  node {
                    url
                    altText
                  }
                }
              }
              availableForSale
              totalInventory
              variants(first: 3) {
                edges {
                  node {
                    id
                    title
                    price {
                      amount
                      currencyCode
                    }
                    availableForSale
                  }
                }
              }
            }
          }
        }
      }
    `;

    try {
      const apiUrl = `https://4fee9w-bw.myshopify.com/api/2024-01/graphql.json`;
      
      console.log('Fetching from:', apiUrl);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Storefront-Access-Token': config.storefrontToken
        },
        body: JSON.stringify({
          query: graphqlQuery,
          variables: { query: searchTerms }
        })
      });

      if (!response.ok) {
        console.error('Storefront API HTTP error:', response.status);
        return [];
      }

      const data = await response.json();
      
      console.log('Storefront API response:', JSON.stringify(data, null, 2));
      
      if (data.errors) {
        console.error('Storefront API errors:', data.errors);
        return [];
      }

      const products = data.data?.products?.edges?.map(edge => edge.node) || [];
      
      console.log(`Found ${products.length} products`);
      
      // Cache products for context
      products.forEach(p => {
        productCache[p.handle] = p;
      });

      return products;
    } catch (error) {
      console.error('Product search error:', error);
      return [];
    }
  }

  /**
   * Detect if user wants to see products or just chatting
   */
  function detectProductIntent(message) {
    const lowerMessage = message.toLowerCase().trim();
    
    // Pure greetings - NO product intent
    const pureGreetings = [
      'merhaba', 'selam', 'hey', 'hi', 'hello', 'hola', 'ciao',
      'günaydın', 'gunaydin', 'iyi günler', 'iyi gunler', 'iyi akşamlar', 'iyi aksamlar',
      'good morning', 'good afternoon', 'good evening', 'nasılsın', 'nasilsin',
      'how are you', 'whats up', "what's up", 'naber', 'ne haber'
    ];
    
    // Check if message is ONLY a greeting
    if (pureGreetings.some(g => lowerMessage === g || lowerMessage === g + '!')) {
      return false;
    }
    
    // Questions without product intent
    const nonProductPhrases = [
      'nasıl yardımcı', 'nasil yardimci', 'ne yapabilirsin', 'kimsin', 'who are you',
      'how can you help', 'what can you do', 'teşekkür', 'tesekkur', 'thank', 'thanks',
      'tamam', 'ok', 'okay', 'anladım', 'anladim', 'got it', 'bye', 'güle güle', 'gule gule',
      'hoşça kal', 'hosca kal', 'görüşürüz', 'gorusuruz'
    ];
    
    if (nonProductPhrases.some(p => lowerMessage.includes(p))) {
      return false;
    }
    
    // Product-related keywords that indicate search intent
    const productKeywords = [
      // Clothing items - English
      'jacket', 'coat', 'dress', 'shirt', 'pants', 'jeans', 'skirt', 'sweater',
      'hoodie', 'blazer', 't-shirt', 'tshirt', 'blouse', 'vest', 'top', 'bottom',
      // Clothing items - Turkish
      'ceket', 'mont', 'kaban', 'elbise', 'gömlek', 'gomlek', 'pantolon', 'etek',
      'kazak', 'bluz', 'yelek', 'tişört', 'tisort', 'triko',
      // Materials
      'leather', 'deri', 'denim', 'kot', 'wool', 'yün', 'yun', 'cotton', 'pamuk',
      'silk', 'ipek', 'kürk', 'kurk', 'fur', 'suede', 'süet', 'suet',
      // Accessories - English
      'bag', 'handbag', 'purse', 'wallet', 'necklace', 'bracelet', 'ring', 'earring',
      'watch', 'belt', 'scarf', 'hat', 'cap', 'shoes', 'boots', 'sneakers', 'heels',
      // Accessories - Turkish
      'çanta', 'canta', 'cüzdan', 'cuzdan', 'kolye', 'bileklik', 'yüzük', 'yuzuk',
      'küpe', 'kupe', 'saat', 'kemer', 'şal', 'sal', 'atkı', 'atki', 'şapka', 'sapka',
      'ayakkabı', 'ayakkabi', 'bot', 'çizme', 'cizme', 'topuklu', 'bere',
      // Action words
      'göster', 'goster', 'bul', 'ara', 'öner', 'oner', 'show', 'find', 'search',
      'recommend', 'suggest', 'looking for', 'arıyorum', 'ariyorum', 'istiyorum',
      'lazım', 'lazim', 'need', 'want', 'buy', 'almak', 'satın', 'satin',
      // Categories
      'ürün', 'urun', 'product', 'products', 'collection', 'koleksiyon',
      'yeni', 'new', 'indirim', 'sale', 'popüler', 'populer', 'popular'
    ];
    
    // Check if any product keyword exists in message
    const hasProductKeyword = productKeywords.some(keyword => {
      // Check for word boundary to avoid false positives
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      return regex.test(lowerMessage);
    });
    
    return hasProductKeyword;
  }

  /**
   * Extract search terms from user message
   * Simple approach: Just clean up the message and send to API
   * Let Shopify's search handle the matching
   */
  function extractSearchTerms(message) {
    const lowerMessage = message.toLowerCase();
    
    // Words to remove (action words, fillers)
    const ignoreWords = new Set([
      // Turkish action/filler words
      'istiyorum', 'göster', 'goster', 'öner', 'oner', 'bana', 'bul', 'ara',
      'var', 'mı', 'mi', 'lütfen', 'lutfen', 'için', 'icin', 'bir', 'tane',
      'sadece', 'olsun', 'hadi', 'bunu', 'buna', 'peki', 'falan', 'filan', 
      'acaba', 'bakar', 'mısın', 'misin', 'musun', 'bakmak', 'ister', 'lazım',
      'lazim', 'gerek', 'olabilir', 'olur', 'isterim',
      // English action/filler words  
      'want', 'show', 'find', 'me', 'please', 'some', 'the', 'a', 'an',
      'need', 'looking', 'for', 'recommend', 'suggest', 'can', 'you',
      'i', 'would', 'like', 'to', 'see', 'get', 'buy'
    ]);

    // Basic Turkish to English for common fashion terms (to help search)
    const basicTranslations = {
      'deri': 'leather',
      'kürk': 'fur',
      'kurk': 'fur',
      'şapka': 'hat',
      'sapka': 'hat',
      'bere': 'beanie',
      'atkı': 'scarf',
      'atki': 'scarf',
      'şal': 'scarf',
      'sal': 'scarf',
      'ceket': 'jacket',
      'mont': 'jacket coat',
      'elbise': 'dress',
      'kazak': 'sweater',
      'gömlek': 'shirt',
      'gomlek': 'shirt',
      'pantolon': 'pants trousers'
    };

    // Extract words from message
    const words = lowerMessage
      .replace(/[.,!?;:'"()]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 1 && !ignoreWords.has(word));

    // Build search terms - keep original + add translation if exists
    const searchTerms = [];
    words.forEach(word => {
      // Always include the original word (for matching product names directly)
      searchTerms.push(word);
      // Also add translation if we have one
      if (basicTranslations[word]) {
        searchTerms.push(basicTranslations[word]);
      }
    });

    // Dedupe and join
    const uniqueTerms = [...new Set(searchTerms.join(' ').split(' '))].filter(t => t.length > 1);
    
    console.log('extractSearchTerms:', lowerMessage, '->', uniqueTerms.join(' '));
    
    return uniqueTerms.length > 0 ? uniqueTerms.join(' ') : '*';
  }

  /**
   * Generate AI response using Gemini API
   * Called AFTER product search - so we know exactly if products were found
   */
  async function generateResponse(userMessage, products, hasProductIntent = false) {
    // Use the persisted language
    const lang = currentLanguage; 
    const foundProducts = products && products.length > 0;
    
    console.log('generateResponse - Lang:', lang, 'hasProductIntent:', hasProductIntent, 'foundProducts:', foundProducts);
    
    // Build clear context for Gemini based on ACTUAL search results
    let situationContext = '';
    
    if (hasProductIntent) {
      if (foundProducts) {
        situationContext = `

DURUM: Kullanıcı ürün istedi ve ${products.length} ÜRÜN BULUNDU!
Ürün kartları mesajının altında otomatik gösterilecek.

GÖREV: KISA pozitif cevap yaz (1-2 cümle).
${lang === 'tr' ? 'Örnek: "Harika seçim! İşte sizin için bulduğum ürünler:"' : 'Example: "Great choice! Here are the products I found:"'}

KESİNLİKLE YAPMA: "bulunamadı", "yok", "maalesef", "unfortunately" kelimelerini KULLANMA - ÜRÜNLER BULUNDU!`;
      } else {
        situationContext = `

DURUM: Kullanıcı ürün istedi ama bu ürün MAĞAZADA BULUNAMADI/YOK.
Kullanıcı "${userMessage}" hakkında soru sordu ancak arama sonucunda 0 ürün döndü.

GÖREV: Özür dile ve alternatif öner (bere, şapka, hoodie, atkı).
⚠️ ÖNEMLİ: HİÇBİR ÜRÜN BULUNAMADI. ASLA "şöyle modellerimiz var" veya "şu renkler var" diye DETAY VERME/UYDURMA!
⚠️ Sadece "Maalesef aradığınız kriterlere uygun ürün bulamadım" de.

${lang === 'tr' ? 'Örnek: "Maalesef bu ürünü stoklarımızda bulamadım. Ancak harika bere ve hoodie modellerimize göz atabilirsiniz!"' : 'Example: "I could not find that product. However, you can check out our beanie and hoodie models!"'}`;
      }
    }

    const recentHistory = chatHistory.slice(-6).map(msg => ({
      role: msg.type === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const systemPrompt = `Sen "${config.shopName}" mağazasının yardımcı asistanısın.

KRİTİK DİL KURALI: Kullanıcıya ${getLanguageName(lang)} dilinde cevap ver. Bu çok önemli!

KURALLAR:
1. HER ZAMAN ${getLanguageName(lang)} dilinde cevap ver - başka dil KULLANMA!
2. KISA cevaplar ver (1-2 cümle max)
3. Samimi ve yardımsever ol
${situationContext}`;

    const contents = [];
    if (recentHistory.length > 0) {
      recentHistory.forEach(msg => contents.push(msg));
    }
    contents.push({ role: 'user', parts: [{ text: userMessage }] });

    const requestBody = {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: contents,
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 512
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
      ]
    };

    try {
      const response = await fetch(`${GEMINI_API_URL}?key=${config.geminiApiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Gemini API error:', errorData);
        throw new Error(`Gemini API error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message);
      }

      let text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      
      // Clean up markdown links
      text = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
      text = text.replace(/https?:\/\/[^\s]+/g, '');
      
      if (!text) {
        text = foundProducts 
          ? getFallbackText(lang, 'productsFound')
          : getFallbackText(lang, 'greeting');
      }

      return { text: text };
    } catch (error) {
      console.error('Gemini API error:', error);
      
      if (foundProducts) {
        return { text: getFallbackText(lang, 'productsFound') };
      }
      return { text: getFallbackText(lang, 'greeting') };
    }
  }

  /**
   * Get fallback text in the correct language
   */
  function getFallbackText(lang, type) {
    const texts = {
      tr: {
        productsFound: 'İşte sizin için bulduğum ürünler!',
        greeting: 'Merhaba! Size nasıl yardımcı olabilirim?'
      },
      en: {
        productsFound: 'Here are the products I found for you!',
        greeting: 'Hello! How can I help you?'
      },
      de: {
        productsFound: 'Hier sind die Produkte, die ich für Sie gefunden habe!',
        greeting: 'Hallo! Wie kann ich Ihnen helfen?'
      },
      fr: {
        productsFound: 'Voici les produits que j\'ai trouvés pour vous!',
        greeting: 'Bonjour! Comment puis-je vous aider?'
      },
      es: {
        productsFound: '¡Aquí están los productos que encontré para ti!',
        greeting: '¡Hola! ¿Cómo puedo ayudarte?'
      },
      it: {
        productsFound: 'Ecco i prodotti che ho trovato per te!',
        greeting: 'Ciao! Come posso aiutarti?'
      },
      nl: {
        productsFound: 'Hier zijn de producten die ik voor je heb gevonden!',
        greeting: 'Hallo! Hoe kan ik je helpen?'
      },
      ja: {
        productsFound: 'あなたのために見つけた商品です！',
        greeting: 'こんにちは！どのようにお手伝いしましょうか？'
      }
    };
    return (texts[lang] && texts[lang][type]) || texts['en'][type];
  }

  /**
   * Format money according to shop settings
   */
  function formatMoney(cents) {
    if (typeof cents === 'string') {
      cents = parseFloat(cents);
    }
    
    const amount = cents.toFixed(2);
    let format = config.moneyFormat || '${{amount}}';
    
    return format
      .replace('{{amount}}', amount)
      .replace('{{amount_no_decimals}}', Math.round(cents))
      .replace('{{amount_with_comma_separator}}', amount.replace('.', ','))
      .replace('{{amount_no_decimals_with_comma_separator}}', Math.round(cents).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','));
  }

  /**
   * Escape HTML to prevent XSS
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Auto-resize textarea
   */
  function autoResize() {
    elements.input.style.height = 'auto';
    elements.input.style.height = Math.min(elements.input.scrollHeight, 120) + 'px';
  }

  /**
   * Handle keyboard events
   */
  function handleKeyDown(e) {
    // Submit on Enter (without Shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(new Event('submit'));
    }
  }

  /**
   * Scroll messages to bottom
   */
  function scrollToBottom() {
    requestAnimationFrame(() => {
      elements.messages.scrollTop = elements.messages.scrollHeight;
    });
  }

  /**
   * Save chat history to session storage
   */
  function saveChatHistory() {
    try {
      const historyToSave = chatHistory.slice(-20); // Keep last 20 messages
      sessionStorage.setItem('chatbot_history', JSON.stringify(historyToSave));
    } catch (e) {
      // Session storage not available
    }
  }

  /**
   * Load chat history from session storage
   */
  function loadChatHistory() {
    try {
      const saved = sessionStorage.getItem('chatbot_history');
      if (saved) {
        const history = JSON.parse(saved);
        if (history && history.length > 0) {
          welcomeShown = true; // Don't show welcome if we have history
          // Restore messages
          history.forEach(msg => {
            addMessageFromHistory(msg);
          });
          chatHistory = history;
        }
      }
    } catch (e) {
      // Session storage not available or invalid data
    }
  }

  /**
   * Add message from history (without saving again)
   */
  function addMessageFromHistory(msg) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chatbot-message chatbot-message--${msg.type}`;

    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    
    if (msg.type === 'bot') {
      // Create mini canvas face for bot avatar
      const miniCanvas = document.createElement('canvas');
      miniCanvas.width = 64;
      miniCanvas.height = 64;
      avatar.appendChild(miniCanvas);
      const ctx = miniCanvas.getContext('2d');
      const mood = (msg.products && msg.products.length > 0) ? 'happy' : 'neutral';
      drawMiniFace(ctx, mood);
    } else {
      avatar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    }

    const content = document.createElement('div');
    content.className = 'chatbot-message__content';
    content.innerHTML = parseMessageText(msg.text);

    if (msg.products && msg.products.length > 0) {
      content.innerHTML += createProductCards(msg.products);
    }

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    elements.messages.appendChild(messageDiv);
  }

  /**
   * Initialize cart notification feature
   */
  function initCartNotification() {
    const container = elements.container;
    if (!container || container.dataset.cartNotification !== 'true') return;

    // Store original fetch
    const originalFetch = window.fetch;

    // Override fetch to intercept cart add requests
    window.fetch = function(...args) {
      const [url, options] = args;
      
      return originalFetch.apply(this, args).then(response => {
        // Check if this is a cart add request
        if (url && (url.includes('/cart/add') || url.includes('/cart/change'))) {
          // Clone response to read it
          response.clone().json().then(data => {
            if (data && (data.items || data.item)) {
              // Item was added to cart
              const item = data.item || (data.items && data.items[0]);
              if (item && url.includes('/cart/add')) {
                handleCartItemAdded(item);
              }
            }
          }).catch(() => {});
        }
        return response;
      });
    };

    // Also listen for form submissions (traditional add to cart)
    document.addEventListener('submit', (e) => {
      const form = e.target;
      if (form.action && form.action.includes('/cart/add')) {
        // Wait a bit for cart to update, then check
        setTimeout(() => {
          fetch('/cart.js')
            .then(r => r.json())
            .then(cart => {
              if (cart.items && cart.items.length > 0) {
                const lastItem = cart.items[0]; // Most recent item
                handleCartItemAdded(lastItem);
              }
            })
            .catch(() => {});
        }, 500);
      }
    });

    console.log('Cart notification listener initialized');
  }

  /**
   * Handle when item is added to cart
   */
  function handleCartItemAdded(item) {
    const badge = document.getElementById('chatbot-badge');
    
    // Show notification badge
    if (badge) {
      badge.classList.add('active');
    }

    // If chatbot is not open, show the badge and wait
    // If chatbot is open, send the message immediately
    const isOpen = elements.drawer.hasAttribute('open');
    
    if (isOpen) {
      sendCartNotificationMessage(item);
      if (badge) badge.classList.remove('active');
    } else {
      // Store item info for when chatbot opens
      sessionStorage.setItem('pendingCartItem', JSON.stringify(item));
    }
  }

  /**
   * Detect language from product title
   */
  function detectLanguageFromTitle(title) {
    if (!title) return 'en';
    
    const lowerTitle = title.toLowerCase();
    
    // German indicators
    const germanChars = /[äöüß]/i;
    const germanWords = ['mit', 'und', 'der', 'die', 'das', 'für', 'aus', 'von', 'bei', 'nach', 'über', 'unter', 'zwischen', 'durch', 'ohne', 'gegen', 'bis', 'seit', 'während', 'wegen', 'trotz', 'statt', 'samt', 'gemäß', 'laut', 'dank', 'anstatt', 'anhand', 'aufgrund', 'infolge', 'mithilfe', 'zugunsten', 'zulasten', 'zuliebe', 'halber', 'halb'];
    if (germanChars.test(title) || germanWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'de';
    }
    
    // French indicators
    const frenchChars = /[éèêëàâçîïôùûœæ]/i;
    const frenchWords = ['avec', 'pour', 'dans', 'sur', 'sous', 'entre', 'vers', 'chez', 'sans', 'avant', 'après', 'depuis', 'pendant', 'durant', 'jusqu', 'malgré', 'selon', 'parmi', 'hors', 'sauf', 'hormis', 'excepté', 'outre', 'voici', 'voilà', 'les', 'des', 'aux', 'une', 'homme', 'femme'];
    if (frenchChars.test(title) || frenchWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'fr';
    }
    
    // Spanish indicators
    const spanishChars = /[ñáéíóúü¿¡]/i;
    const spanishWords = ['con', 'para', 'sobre', 'bajo', 'entre', 'hacia', 'desde', 'durante', 'mediante', 'según', 'contra', 'tras', 'ante', 'sin', 'hombre', 'mujer', 'niño', 'niña'];
    if (spanishChars.test(title) || spanishWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'es';
    }
    
    // Italian indicators
    const italianWords = ['con', 'per', 'tra', 'fra', 'sopra', 'sotto', 'dentro', 'fuori', 'davanti', 'dietro', 'accanto', 'lungo', 'mediante', 'nonostante', 'durante', 'verso', 'presso', 'uomo', 'donna', 'bambino'];
    if (italianWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'it';
    }
    
    // Turkish indicators
    const turkishChars = /[şğıİüöç]/i;
    const turkishWords = ['ile', 'için', 'veya', 'ama', 'fakat', 'ancak', 'çünkü', 'eğer', 'hem', 'ya', 'ne', 'ki', 'de', 'da', 'mi', 'mu', 'mı', 'dahi', 'bile', 'kadar', 'gibi', 'erkek', 'kadın', 'çocuk'];
    if (turkishChars.test(title) || turkishWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'tr';
    }
    
    // Dutch indicators
    const dutchWords = ['met', 'voor', 'van', 'naar', 'door', 'tegen', 'tussen', 'onder', 'boven', 'naast', 'achter', 'zonder', 'binnen', 'buiten', 'tijdens', 'heren', 'dames'];
    if (dutchWords.some(w => lowerTitle.includes(` ${w} `) || lowerTitle.startsWith(`${w} `) || lowerTitle.endsWith(` ${w}`))) {
      return 'nl';
    }
    
    // Japanese indicators (katakana/hiragana)
    if (/[\u3040-\u309F\u30A0-\u30FF]/.test(title)) {
      return 'ja';
    }
    
    // Also check Shopify locale as fallback
    if (window.Shopify && window.Shopify.locale) {
      return window.Shopify.locale.substring(0, 2);
    }
    
    // Default to English
    return 'en';
  }

  /**
   * Get cart notification texts based on language
   */
  function getCartNotificationTexts(lang) {
    const texts = {
      tr: {
        added: 'sepetinize eklendi!',
        question: 'Sepetinizi görüntülemek ister misiniz?',
        yes: '✓ Evet',
        no: '✗ Hayır',
        yesResponse: 'Evet, sepeti göster',
        noResponse: 'Hayır, alışverişe devam',
        redirecting: '✓ Sepete yönlendiriliyorsunuz...',
        continue: 'Tamam, alışverişe devam edebilirsiniz! 🛍️',
        helpMore: 'Size başka nasıl yardımcı olabilirim? 😊'
      },
      en: {
        added: 'has been added to your cart!',
        question: 'Would you like to view your cart?',
        yes: '✓ Yes',
        no: '✗ No',
        yesResponse: 'Yes, show cart',
        noResponse: 'No, continue shopping',
        redirecting: '✓ Redirecting to cart...',
        continue: 'Okay, continue shopping! 🛍️',
        helpMore: 'How else can I help you? 😊'
      },
      de: {
        added: 'wurde Ihrem Warenkorb hinzugefügt!',
        question: 'Möchten Sie Ihren Warenkorb ansehen?',
        yes: '✓ Ja',
        no: '✗ Nein',
        yesResponse: 'Ja, Warenkorb anzeigen',
        noResponse: 'Nein, weiter einkaufen',
        redirecting: '✓ Weiterleitung zum Warenkorb...',
        continue: 'Okay, weiter einkaufen! 🛍️',
        helpMore: 'Wie kann ich Ihnen sonst helfen? 😊'
      },
      fr: {
        added: 'a été ajouté à votre panier !',
        question: 'Voulez-vous voir votre panier ?',
        yes: '✓ Oui',
        no: '✗ Non',
        yesResponse: 'Oui, voir le panier',
        noResponse: 'Non, continuer mes achats',
        redirecting: '✓ Redirection vers le panier...',
        continue: 'D\'accord, continuez vos achats ! 🛍️',
        helpMore: 'Comment puis-je vous aider autrement ? 😊'
      },
      es: {
        added: 'se ha añadido a tu carrito!',
        question: '¿Te gustaría ver tu carrito?',
        yes: '✓ Sí',
        no: '✗ No',
        yesResponse: 'Sí, ver carrito',
        noResponse: 'No, seguir comprando',
        redirecting: '✓ Redirigiendo al carrito...',
        continue: '¡Vale, sigue comprando! 🛍️',
        helpMore: '¿En qué más puedo ayudarte? 😊'
      },
      it: {
        added: 'è stato aggiunto al carrello!',
        question: 'Vuoi vedere il tuo carrello?',
        yes: '✓ Sì',
        no: '✗ No',
        yesResponse: 'Sì, mostra carrello',
        noResponse: 'No, continua lo shopping',
        redirecting: '✓ Reindirizzamento al carrello...',
        continue: 'Ok, continua lo shopping! 🛍️',
        helpMore: 'Come posso aiutarti? 😊'
      },
      nl: {
        added: 'is toegevoegd aan je winkelwagen!',
        question: 'Wil je je winkelwagen bekijken?',
        yes: '✓ Ja',
        no: '✗ Nee',
        yesResponse: 'Ja, toon winkelwagen',
        noResponse: 'Nee, verder winkelen',
        redirecting: '✓ Doorsturen naar winkelwagen...',
        continue: 'Oké, verder winkelen! 🛍️',
        helpMore: 'Hoe kan ik je verder helpen? 😊'
      },
      ja: {
        added: 'がカートに追加されました！',
        question: 'カートを見ますか？',
        yes: '✓ はい',
        no: '✗ いいえ',
        yesResponse: 'はい、カートを見る',
        noResponse: 'いいえ、買い物を続ける',
        redirecting: '✓ カートに移動中...',
        continue: 'お買い物を続けてください！🛍️',
        helpMore: '他にお手伝いできることはありますか？😊'
      }
    };
    
    return texts[lang] || texts['en'];
  }

  /**
   * Send cart notification message with Yes/No buttons
   */
  function sendCartNotificationMessage(item) {
    const productName = item.product_title || item.title || 'Product';
    const variant = item.variant_title ? ` (${item.variant_title})` : '';
    
    // Detect language from product title
    const detectedLang = detectLanguageFromTitle(productName);
    const texts = getCartNotificationTexts(detectedLang);
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chatbot-message chatbot-message--bot';
    
    // Create avatar with canvas face
    const avatar = document.createElement('div');
    avatar.className = 'chatbot-message__avatar';
    const miniCanvas = document.createElement('canvas');
    miniCanvas.width = 64;
    miniCanvas.height = 64;
    avatar.appendChild(miniCanvas);
    const ctx = miniCanvas.getContext('2d');
    drawMiniFace(ctx, 'excited');
    
    // Create content with message and buttons
    const content = document.createElement('div');
    content.className = 'chatbot-message__content';
    content.innerHTML = `
      <p>🛒 <strong>${productName}${variant}</strong> ${texts.added}</p>
      <p style="margin-top: 8px;">${texts.question}</p>
      <div class="chatbot-cart-actions" style="display: flex; gap: 8px; margin-top: 12px;">
        <button type="button" class="chatbot-cart-action chatbot-cart-action--yes" style="
          flex: 1;
          padding: 10px 16px;
          background: rgb(var(--primary-button-background));
          color: rgb(var(--primary-button-text-color));
          border: none;
          border-radius: var(--button-border-radius);
          cursor: pointer;
          font-weight: 500;
          font-size: 14px;
          transition: opacity 0.2s;
        ">${texts.yes}</button>
        <button type="button" class="chatbot-cart-action chatbot-cart-action--no" style="
          flex: 1;
          padding: 10px 16px;
          background: transparent;
          color: rgb(var(--text-color));
          border: 1px solid rgb(var(--border-color));
          border-radius: var(--button-border-radius);
          cursor: pointer;
          font-weight: 500;
          font-size: 14px;
          transition: background 0.2s;
        ">${texts.no}</button>
      </div>
    `;
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    elements.messages.appendChild(messageDiv);
    
    // Add button click handlers
    const yesBtn = content.querySelector('.chatbot-cart-action--yes');
    const noBtn = content.querySelector('.chatbot-cart-action--no');
    const actionsDiv = content.querySelector('.chatbot-cart-actions');
    
    yesBtn.addEventListener('click', () => {
      // Add user response message
      addMessage(texts.yesResponse, 'user');
      
      // Disable buttons
      actionsDiv.innerHTML = `<p style="color: rgb(var(--text-color)); opacity: 0.7; font-style: italic;">${texts.redirecting}</p>`;
      
      // Open cart drawer or redirect to cart page
      setTimeout(() => {
        openCart();
      }, 500);
    });
    
    noBtn.addEventListener('click', () => {
      // Add user response message
      addMessage(texts.noResponse, 'user');
      
      // Replace buttons with response
      actionsDiv.innerHTML = `<p style="color: rgb(var(--text-color)); opacity: 0.7; font-style: italic;">${texts.continue}</p>`;
      
      // Send friendly response
      setTimeout(() => {
        addMessage(texts.helpMore, 'bot');
      }, 500);
    });
    
    scrollToBottom();
    
    // Confetti effect
    if (window.ChatbotCanvas && window.ChatbotCanvas.confetti) {
      window.ChatbotCanvas.confetti();
    }
    
    // Set mood to excited
    if (window.ChatbotCanvas && window.ChatbotCanvas.setMood) {
      window.ChatbotCanvas.setMood('excited');
    }
  }

  /**
   * Open cart (drawer or page)
   */
  function openCart() {
    // Try to open cart drawer first (if theme supports it)
    const cartDrawerTrigger = document.querySelector('[aria-controls="cart-drawer"], [data-cart-toggle], .js-cart-toggle, .header__icon-wrapper[href*="/cart"]');
    
    if (cartDrawerTrigger) {
      cartDrawerTrigger.click();
    } else {
      // Fallback to cart page
      window.location.href = '/cart';
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose API for external use
  window.Chatbot = {
    open: openChatbot,
    close: closeChatbot,
    toggle: toggleChatbot,
    sendMessage: (msg) => {
      elements.input.value = msg;
      handleSubmit(new Event('submit'));
    },
    notifyCartAdd: handleCartItemAdded
  };

})();
