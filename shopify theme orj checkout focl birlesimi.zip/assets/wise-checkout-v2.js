/**
 * Wise Checkout V2 — Pixel-perfect Wise clone
 * HMAC signed requests + timestamp + cart verification + URL obfuscation
 */
(function () {
  'use strict';

  var CFG = window.wiseCheckoutV2Config || {};
  var _e = CFG.serverEnc || '';
  var SERVER = _e ? atob(_e) : '';
  var SHOP = CFG.shopDomain || '';

  /* HMAC key — XOR + shuffle obfuscated */
  var _d=[92,49,79,91,106,55,57,116,114,79,109,94,103,113,71,126,103,66,109,63,50,104,48,68,90,89,107,49,90,112,48,55,97,51,116];
  var _p=[10,23,25,13,15,32,26,18,7,16,33,34,21,30,31,12,1,22,3,4,29,9,20,19,2,6,27,14,28,5,11,8,24,17,0];
  var HMAC_KEY=(function(){var r=new Array(_p.length);for(var i=0;i<_p.length;i++)r[_p[i]]=String.fromCharCode(_d[i]^(_p[i]%7+3));return r.join('');}());

  var cart = null;

  /* ─── Helpers ─── */
  function fmt(cents) {
    return (cents / 100).toFixed(2).replace('.', ',') + ' EUR';
  }

  function $(id) {
    return document.getElementById(id);
  }

  /* ─── HMAC Signing ─── */
  function signRequest(body) {
    var ts = Date.now().toString();
    var payload = ts + '.' + JSON.stringify(body);
    var enc = new TextEncoder();
    return crypto.subtle.importKey(
      'raw', enc.encode(HMAC_KEY), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    ).then(function (key) {
      return crypto.subtle.sign('HMAC', key, enc.encode(payload));
    }).then(function (sig) {
      var hex = Array.from(new Uint8Array(sig)).map(function (b) {
        return b.toString(16).padStart(2, '0');
      }).join('');
      return { signature: hex, timestamp: ts };
    });
  }

  /* ─── Render Order Summary ─── */
  function renderSummary() {
    if (!cart || !cart.items.length) return;

    var html = '';
    cart.items.forEach(function (item) {
      var imgSrc = item.image
        ? item.image.replace(/(\.[a-z]+)(\?|$)/, '_180x$1$2')
        : 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="56" height="56"><rect width="56" height="56" fill="%23f5f5f5"/></svg>';
      var variant = item.variant_title || '';

      html += '<div class="w-item">';
      html += '<div class="w-item__img-wrap">';
      html += '<img class="w-item__img" src="' + imgSrc + '" alt="' + item.title + '">';
      if (item.quantity > 1) {
        html += '<span class="w-item__badge">' + item.quantity + '</span>';
      }
      html += '</div>';
      html += '<div class="w-item__info">';
      html += '<div class="w-item__title">' + item.title + '</div>';
      if (variant) html += '<div class="w-item__variant">' + variant + '</div>';
      html += '</div>';
      html += '<div class="w-item__price">' + fmt(item.final_line_price) + '</div>';
      html += '</div>';
    });

    var totalStr = fmt(cart.total_price);
    $('wv2-amount').textContent = totalStr;
    if ($('wv2-items')) $('wv2-items').innerHTML = html;
    if ($('wv2-bar-total')) $('wv2-bar-total').textContent = totalStr;
    if ($('wv2-subtotal')) $('wv2-subtotal').textContent = totalStr;
    if ($('wv2-total')) $('wv2-total').textContent = totalStr;
    if ($('wv2-totals')) $('wv2-totals').style.display = '';
  }

  /* ─── Address Autocomplete (Google Places) ─── */
  function initAddressAutocomplete() {
    var addressInput = $('wv2-address');
    if (!addressInput) return;

    function setup() {
      var countrySelect = $('wv2-country');
      var selectedCountry = countrySelect ? countrySelect.value.toLowerCase() : '';

      var ac = new google.maps.places.Autocomplete(addressInput, {
        types: ['address'],
        fields: ['address_components'],
        componentRestrictions: selectedCountry ? { country: selectedCountry } : undefined
      });

      addressInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          var pac = document.querySelector('.pac-container');
          if (pac && pac.offsetParent !== null) e.preventDefault();
        }
      });

      ac.addListener('place_changed', function () {
        var place = ac.getPlace();
        if (!place || !place.address_components) return;

        var comp = {};
        place.address_components.forEach(function (c) {
          var t = c.types[0];
          if (t === 'street_number')        comp.num = c.long_name;
          if (t === 'route')                comp.route = c.long_name;
          if (t === 'locality')             comp.city = c.long_name;
          if (t === 'postal_town' && !comp.city) comp.city = c.long_name;
          if (t === 'sublocality_level_1' && !comp.city) comp.city = c.long_name;
          if (t === 'administrative_area_level_1' && !comp.city) comp.city = c.long_name;
          if (t === 'postal_code')          comp.postal = c.long_name;
          if (t === 'country')              comp.country = c.short_name;
        });

        var street = comp.route || '';
        if (comp.num) street = street ? (street + ' ' + comp.num) : comp.num;

        addressInput.blur();
        var pacEl = document.querySelector('.pac-container');
        if (pacEl) pacEl.style.display = 'none';

        if (street) addressInput.value = street;

        if ($('wv2-city') && comp.city) $('wv2-city').value = comp.city;
        if ($('wv2-postal') && comp.postal) $('wv2-postal').value = comp.postal;

        if (countrySelect && comp.country) {
          for (var i = 0; i < countrySelect.options.length; i++) {
            if (countrySelect.options[i].value === comp.country) {
              countrySelect.value = comp.country;
              break;
            }
          }
        }

        var aptInput = $('wv2-apartment');
        if (aptInput) setTimeout(function () { aptInput.focus(); }, 50);
      });

      if (countrySelect) {
        countrySelect.addEventListener('change', function () {
          ac.setComponentRestrictions({ country: this.value.toLowerCase() });
        });
      }
    }

    if (typeof google !== 'undefined' && google.maps && google.maps.places) {
      setup();
    } else {
      var attempts = 0;
      var waitInterval = setInterval(function () {
        attempts++;
        if (typeof google !== 'undefined' && google.maps && google.maps.places) {
          clearInterval(waitInterval);
          setup();
        } else if (attempts > 100) {
          clearInterval(waitInterval);
        }
      }, 100);
    }
  }

  /* ─── Validation ─── */
  function validate() {
    var fields = [
      { id: 'wv2-email',    errId: 'wv2-email-err' },
      { id: 'wv2-fullname', errId: 'wv2-fullname-err' },
      { id: 'wv2-address',  errId: 'wv2-address-err' },
      { id: 'wv2-city',     errId: 'wv2-city-err' },
      { id: 'wv2-postal',   errId: 'wv2-postal-err' }
    ];
    var ok = true;

    // Clear previous errors
    document.querySelectorAll('.w-input--error').forEach(function (el) {
      el.classList.remove('w-input--error');
    });
    document.querySelectorAll('.w-error-prompt.visible').forEach(function (el) {
      el.classList.remove('visible');
    });

    fields.forEach(function (f) {
      var input = $(f.id);
      if (!input) return;
      var val = input.value.trim();
      if (!val) {
        input.classList.add('w-input--error');
        var errEl = $(f.errId);
        if (errEl) errEl.classList.add('visible');
        ok = false;
      }
    });

    // Email format check
    var email = $('wv2-email');
    if (email && email.value.trim()) {
      var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!re.test(email.value.trim())) {
        email.classList.add('w-input--error');
        var errEl = $('wv2-email-err');
        if (errEl) errEl.classList.add('visible');
        ok = false;
      }
    }

    return ok;
  }

  /* ─── Submit → Create Order + Wise Link → Redirect ─── */
  window.WV2 = window.WV2 || {};

  WV2.submit = function () {
    if (!validate()) {
      var err = document.querySelector('.w-input--error');
      if (err) err.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    var btn = $('wv2-btn');
    var btnText = $('wv2-btn-text');
    btn.disabled = true;
    btnText.textContent = 'Processing…';
    btn.insertAdjacentHTML('afterbegin', '<span class="w-spinner" style="margin-right:8px;"></span>');

    var amount = (cart.total_price / 100).toFixed(2);

    // Parse full name into first + last
    var fullName = ($('wv2-fullname') ? $('wv2-fullname').value.trim() : '').split(/\s+/);
    var firstName = fullName[0] || '';
    var lastName = fullName.slice(1).join(' ') || '';

    var email     = $('wv2-email')     ? $('wv2-email').value.trim()     : '';
    var address   = $('wv2-address')   ? $('wv2-address').value.trim()   : '';
    var apartment = $('wv2-apartment') ? $('wv2-apartment').value.trim() : '';
    var city      = $('wv2-city')      ? $('wv2-city').value.trim()      : '';
    var postal    = $('wv2-postal')    ? $('wv2-postal').value.trim()    : '';
    var country   = $('wv2-country')   ? $('wv2-country').value          : 'DE';

    var cartItems = cart.items.map(function (item) {
      return {
        variant_id: item.variant_id,
        quantity: item.quantity,
        title: item.title,
        price: (item.final_line_price / 100 / item.quantity).toFixed(2)
      };
    });

    var cartToken = '';
    try {
      var m = document.cookie.match(/cart=([^;]+)/);
      if (m) cartToken = decodeURIComponent(m[1]);
    } catch (e) {}

    /* Read Meta _fbp and _fbc cookies for Conversions API matching */
    var fbp = '';
    var fbc = '';
    var fbi = '';
    try {
      var fbpMatch = document.cookie.match(/_fbp=([^;]+)/);
      if (fbpMatch) fbp = decodeURIComponent(fbpMatch[1]);
      var fbcMatch = document.cookie.match(/_fbc=([^;]+)/);
      if (fbcMatch) fbc = decodeURIComponent(fbcMatch[1]);
      /* If no _fbc cookie but fbclid in URL, build it */
      if (!fbc) {
        var params = new URLSearchParams(window.location.search);
        var fbclid = params.get('fbclid');
        if (fbclid) fbc = 'fb.1.' + Date.now() + '.' + fbclid;
      }
      /* Read _fbi (client IP from Parameter Builder) for IPv6 CAPI matching */
      var fbiMatch = document.cookie.match(/_fbi=([^;]+)/);
      if (fbiMatch) fbi = decodeURIComponent(fbiMatch[1]);
    } catch (e) {}

    var requestBody = {
      amount: parseFloat(amount),
      currency: 'EUR',
      email: email,
      firstName: firstName,
      lastName: lastName,
      address: address,
      apartment: apartment,
      city: city,
      postal: postal,
      country: country,
      cartItems: cartItems,
      cartToken: cartToken,
      fbp: fbp,
      fbc: fbc,
      fbi: fbi
    };

    signRequest(requestBody)
      .then(function (sig) {
        return fetch(SERVER + '/create-order', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Signature': sig.signature,
            'X-Timestamp': sig.timestamp
          },
          body: JSON.stringify(requestBody)
        });
      })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.link) {
          window.location.href = data.link;
        } else {
          throw new Error(data.error || 'Failed to create payment link');
        }
      })
      .catch(function (err) {
        console.error('Wise checkout v2 error:', err);
        btn.disabled = false;
        // Remove spinner
        var sp = btn.querySelector('.w-spinner');
        if (sp) sp.remove();
        btnText.textContent = 'Continue to payment';

        var msg = err.message || 'Payment error. Please try again.';
        var errBox = $('wv2-error');
        if (errBox) {
          errBox.textContent = msg;
          errBox.style.display = 'block';
          errBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
          alert(msg);
        }
      });
  };

  /* ─── Init — Load Cart ─── */
  function init() {
    fetch('/cart.js', { credentials: 'same-origin' })
      .then(function (res) {
        console.log('[WV2] cart.js status:', res.status);
        return res.json();
      })
      .then(function (data) {
        console.log('[WV2] cart data:', data.item_count, 'items, total:', data.total_price);
        cart = data;
        $('wv2-loading').style.display = 'none';

        if (!cart.items.length) {
          $('wv2-empty').style.display = 'block';
          return;
        }

        $('wv2-page').style.display = '';
        renderSummary();
        initAddressAutocomplete();

        /* Meta Pixel — InitiateCheckout */
        if (typeof fbq === 'function') {
          fbq('track', 'InitiateCheckout', {
            content_ids: cart.items.map(function(i){ return String(i.variant_id); }),
            content_type: 'product',
            value: (cart.total_price / 100).toFixed(2),
            currency: cart.currency || 'EUR',
            num_items: cart.item_count
          });
        }
      })
      .catch(function (err) {
        console.error('Cart load error:', err);
        $('wv2-loading').style.display = 'none';
        $('wv2-empty').style.display = 'block';
      });
  }

  /* Remove error styling on focus */
  document.addEventListener('focusin', function (e) {
    if (e.target.classList && e.target.classList.contains('w-input--error')) {
      e.target.classList.remove('w-input--error');
      // Also hide the error prompt
      var parent = e.target.closest('.w-field');
      if (parent) {
        var errPrompt = parent.querySelector('.w-error-prompt');
        if (errPrompt) errPrompt.classList.remove('visible');
      }
    }
  });

  /* Hide error box on interaction */
  document.addEventListener('focusin', function () {
    var errBox = $('wv2-error');
    if (errBox && errBox.style.display === 'block') {
      errBox.style.display = 'none';
    }
  });

  /* Start */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
