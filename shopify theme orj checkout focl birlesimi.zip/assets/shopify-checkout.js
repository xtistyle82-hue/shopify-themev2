/**
 * Shopify Checkout Intercept — Redirects checkout to Store B (pay.nexorinc.com)
 *
 * When customer clicks "Checkout" on Store A (nexorinc.com), this script:
 *   1. Intercepts the checkout form/link
 *   2. Fetches current cart from /cart.js
 *   3. Sends cart data to shopify-checkout-server
 *   4. Redirects to Store B's Shopify Payments checkout (pay.nexorinc.com)
 *
 * HMAC signed requests (same shared secret as Wise checkout)
 * Does NOT interfere with Wise checkout page (/pages/wise-checkout-v2)
 */
(function () {
  'use strict';

  var CFG = window.shopifyCheckoutConfig || {};
  var _e = CFG.serverEnc || '';
  var SERVER = _e ? atob(_e) : (CFG.serverUrl || '');
  if (!SERVER) return;

  /* ─── HMAC key — XOR + shuffle obfuscated (same as Wise checkout v2) ─── */
  var _d=[92,49,79,91,106,55,57,116,114,79,109,94,103,113,71,126,103,66,109,63,50,104,48,68,90,89,107,49,90,112,48,55,97,51,116];
  var _p=[10,23,25,13,15,32,26,18,7,16,33,34,21,30,31,12,1,22,3,4,29,9,20,19,2,6,27,14,28,5,11,8,24,17,0];
  var HMAC_KEY=(function(){var r=new Array(_p.length);for(var i=0;i<_p.length;i++)r[_p[i]]=String.fromCharCode(_d[i]^(_p[i]%7+3));return r.join('');}());

  /* ─── State ─── */
  var isProcessing = false;

  /* ─── HMAC Signing ─── */
  function signRequest(body) {
    var ts = Date.now().toString();
    var payload = ts + '.' + JSON.stringify(body);
    var enc = new TextEncoder();
    return crypto.subtle.importKey(
      'raw', enc.encode(HMAC_KEY), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    ).then(function (key) {
      return crypto.subtle.sign('HMAC', key, enc.encode(payload));
    }).then(function (sig) {
      var hex = Array.from(new Uint8Array(sig)).map(function (b) {
        return b.toString(16).padStart(2, '0');
      }).join('');
      return { signature: hex, timestamp: ts };
    });
  }

  /* ─── Helpers ─── */
  function getCartToken() {
    try {
      var m = document.cookie.match(/cart=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : '';
    } catch (e) { return ''; }
  }

  function getMetaCookies() {
    var fbp = '', fbc = '', fbi = '';
    try {
      var m1 = document.cookie.match(/_fbp=([^;]+)/);
      if (m1) fbp = decodeURIComponent(m1[1]);
      var m2 = document.cookie.match(/_fbc=([^;]+)/);
      if (m2) fbc = decodeURIComponent(m2[1]);
      if (!fbc) {
        var params = new URLSearchParams(window.location.search);
        var fbclid = params.get('fbclid');
        if (fbclid) fbc = 'fb.1.' + Date.now() + '.' + fbclid;
      }
      var m3 = document.cookie.match(/_fbi=([^;]+)/);
      if (m3) fbi = decodeURIComponent(m3[1]);
    } catch (e) {}
    return { fbp: fbp, fbc: fbc, fbi: fbi };
  }

  /* ─── Button Loading State ─── */
  var activeBtn = null;

  function showButtonLoading() {
    /* Find the clicked checkout button and add spinner inside it */
    var btns = document.querySelectorAll('.checkout-button, [data-shopify-checkout-btn]');
    btns.forEach(function (btn) {
      if (btn.classList.contains('is-loading')) activeBtn = btn;
    });
    /* If no .is-loading found, pick the first checkout button */
    if (!activeBtn && btns.length) {
      activeBtn = btns[0];
      activeBtn.classList.add('is-loading');
      activeBtn.style.pointerEvents = 'none';
    }
  }

  function hideButtonLoading() {
    if (activeBtn) {
      activeBtn.classList.remove('is-loading');
      activeBtn.style.pointerEvents = '';
      activeBtn = null;
    }
    isProcessing = false;
  }

  /* ─── Show Error Toast ─── */
  function showError(msg) {
    hideButtonLoading();
    var toast = document.createElement('div');
    toast.style.cssText =
      'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);' +
      'background:#cb272f;color:#fff;padding:12px 24px;border-radius:10px;' +
      'font-size:14px;font-weight:500;z-index:999999;max-width:90%;text-align:center;' +
      'font-family:Inter,Helvetica,Arial,sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.15);';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(function () { toast.remove(); }, 5000);
  }

  /* ─── Core: Redirect to Shopify Checkout ─── */
  function redirectToShopifyCheckout() {
    if (isProcessing) return;
    isProcessing = true;
    showButtonLoading();

    fetch('/cart.js', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (cart) {
        if (!cart.items || !cart.items.length) {
          hideButtonLoading();
          window.location.href = '/cart';
          return;
        }

        var cartItems = cart.items.map(function (item) {
          return {
            variant_id: item.variant_id,
            product_id: item.product_id,
            quantity: item.quantity,
            title: item.title,
            variant_title: item.variant_title || '',
            price: (item.final_line_price / 100 / item.quantity).toFixed(2),
            image: item.image || '',
          };
        });

        var totalAmount = (cart.total_price / 100).toFixed(2);
        var meta = getMetaCookies();

        var requestBody = {
          cartItems: cartItems,
          totalAmount: parseFloat(totalAmount),
          currency: cart.currency || 'EUR',
          cartToken: getCartToken(),
          fbp: meta.fbp,
          fbc: meta.fbc,
          fbi: meta.fbi,
        };

        return signRequest(requestBody)
          .then(function (sig) {
            return fetch(SERVER + '/create-shopify-checkout', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Signature': sig.signature,
                'X-Timestamp': sig.timestamp,
              },
              body: JSON.stringify(requestBody),
            });
          })
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (data.checkoutUrl) {
              /* Meta Pixel — InitiateCheckout */
              if (typeof fbq === 'function') {
                fbq('track', 'InitiateCheckout', {
                  content_ids: cartItems.map(function (i) { return String(i.variant_id); }),
                  content_type: 'product',
                  value: totalAmount,
                  currency: cart.currency || 'EUR',
                  num_items: cart.item_count,
                });
              }

              /* Save checkout ID for thank-you page (optional) */
              try {
                sessionStorage.setItem('sc_checkout_id', data.checkoutId || '');
                sessionStorage.setItem('sc_checkout_amount', totalAmount);
              } catch (e) {}

              /* Small delay to let Store B activate the checkout page */
              setTimeout(function () {
                window.location.href = data.checkoutUrl;
              }, 1500);
            } else {
              throw new Error(data.error || 'Checkout failed');
            }
          });
      })
      .catch(function (err) {
        console.error('[ShopifyCheckout] Error:', err);
        showError(err.message || 'Checkout error. Please try again.');
      });
  }

  /* ─── Intercept Checkout Buttons & Forms ─── */
  function isWiseCheckoutPage() {
    var path = window.location.pathname.toLowerCase();
    return path.indexOf('wise-checkout') !== -1;
  }

  function isCheckoutUrl(url) {
    if (!url) return false;
    // Match /checkout but NOT /pages/wise-checkout or /pages/shopify-checkout
    return (
      (url.indexOf('/checkout') !== -1 && url.indexOf('/pages/') === -1) ||
      url.indexOf('/cart/checkout') !== -1
    );
  }

  function shouldIntercept() {
    // Don't intercept on Wise checkout page
    if (isWiseCheckoutPage()) return false;
    // Don't intercept on admin/editor
    if (window.Shopify && window.Shopify.designMode) return false;
    return true;
  }

  /* Intercept form submissions to /checkout */
  document.addEventListener('submit', function (e) {
    if (!shouldIntercept()) return;
    var form = e.target;
    if (!form) return;

    /* Direct checkout URL in form action */
    if (form.action && isCheckoutUrl(form.action)) {
      e.preventDefault();
      e.stopPropagation();
      redirectToShopifyCheckout();
      return;
    }

    /* Shopify cart form with hidden checkout input (action="/cart" + name="checkout") */
    if (form.querySelector('input[name="checkout"]') || form.querySelector('button[name="checkout"]')) {
      e.preventDefault();
      e.stopPropagation();
      redirectToShopifyCheckout();
      return;
    }
  }, true);

  /* Intercept link clicks to /checkout */
  document.addEventListener('click', function (e) {
    if (!shouldIntercept()) return;
    var link = e.target.closest('a[href]');
    if (link && isCheckoutUrl(link.href)) {
      e.preventDefault();
      e.stopPropagation();
      redirectToShopifyCheckout();
      return;
    }

    /* Also intercept buttons with name="checkout" or data-checkout */
    var btn = e.target.closest('button[name="checkout"], button[data-checkout], input[name="checkout"]');
    if (btn) {
      e.preventDefault();
      e.stopPropagation();
      redirectToShopifyCheckout();
      return;
    }
  }, true);

  /* Intercept Shopify's built-in checkout redirect via fetch/XHR */
  (function () {
    var origAssign = Object.getOwnPropertyDescriptor(Location.prototype, 'assign');
    if (origAssign && origAssign.configurable !== false) {
      try {
        Object.defineProperty(window.location, 'assign', {
          value: function (url) {
            if (shouldIntercept() && isCheckoutUrl(url)) {
              redirectToShopifyCheckout();
              return;
            }
            origAssign.value.call(this, url);
          },
        });
      } catch (e) { /* some browsers block this */ }
    }
  })();

  /* Expose for programmatic use */
  window.ShopifyCheckout = {
    redirect: redirectToShopifyCheckout,
    isProcessing: function () { return isProcessing; },
  };

  console.log('[ShopifyCheckout] Intercept active — checkout will redirect to ' + (CFG.storeBDomain || 'Store B'));

})();
