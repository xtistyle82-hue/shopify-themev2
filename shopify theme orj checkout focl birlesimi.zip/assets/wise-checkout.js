/**
 * Wise Checkout — Frontend Logic v2.1 (Security Hardened)
 * HMAC signed requests + timestamp + cart verification + URL obfuscation
 */
(function () {
  'use strict';

  var CFG = window.wiseCheckoutConfig || {};
  // Obfuscated server URL — decoded at runtime, not plain text in source
  var _e = CFG.serverEnc || '';
  var SERVER = _e ? atob(_e) : (CFG.serverUrl || '');
  var SHOP = CFG.shopDomain || '';
  // HMAC key — XOR + shuffle obfuscated (not readable in source)
  var _d=[92,49,79,91,106,55,57,116,114,79,109,94,103,113,71,126,103,66,109,63,50,104,48,68,90,89,107,49,90,112,48,55,97,51,116];
  var _p=[10,23,25,13,15,32,26,18,7,16,33,34,21,30,31,12,1,22,3,4,29,9,20,19,2,6,27,14,28,5,11,8,24,17,0];
  var HMAC_KEY=(function(){var r=new Array(_p.length);for(var i=0;i<_p.length;i++)r[_p[i]]=String.fromCharCode(_d[i]^(_p[i]%7+3));return r.join('');}());

  var cart = null;

  /* =========================================
     HELPERS
     ========================================= */
  function fmt(cents) {
    return '€' + (cents / 100).toFixed(2).replace('.', ',');
  }

  function $(id) {
    return document.getElementById(id);
  }

  /* =========================================
     HMAC SIGNING (Web Crypto API)
     ========================================= */
  function signRequest(body) {
    var ts = Date.now().toString();
    var payload = ts + '.' + JSON.stringify(body);
    var enc = new TextEncoder();
    return crypto.subtle.importKey(
      'raw', enc.encode(HMAC_KEY), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    ).then(function (key) {
      return crypto.subtle.sign('HMAC', key, enc.encode(payload));
    }).then(function (sig) {
      var hex = Array.from(new Uint8Array(sig)).map(function (b) {
        return b.toString(16).padStart(2, '0');
      }).join('');
      return { signature: hex, timestamp: ts };
    });
  }

  /* =========================================
     ORDER SUMMARY
     ========================================= */
  function renderSummary() {
    if (!cart || !cart.items.length) return;

    // Read block settings from data attributes
    var itemsEl = $('os-items');
    var imgSize = (itemsEl && itemsEl.dataset.imgSize) || '64';
    var badgeSize = (itemsEl && itemsEl.dataset.badgeSize) || '20';
    var badgeBg = (itemsEl && itemsEl.dataset.badgeBg) || '#727272';

    // Items
    var html = '';
    cart.items.forEach(function (item) {
      var imgSrc = item.image
        ? item.image.replace(/(\.[a-z]+)(\?|$)/, '_180x$1$2')
        : 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" fill="%23f5f5f5"/></svg>';
      var variant = item.variant_title || '';

      html += '<div class="os-item">';
      html += '<div class="os-item__img-wrap" style="width:' + imgSize + 'px;height:' + imgSize + 'px;">';
      html += '<img src="' + imgSrc + '" alt="' + item.title + '">';
      if (item.quantity > 1) {
        html += '<span class="os-item__badge" style="width:' + badgeSize + 'px;height:' + badgeSize + 'px;background:' + badgeBg + ';">' + item.quantity + '</span>';
      }
      html += '</div>';
      html += '<div class="os-item__info">';
      html += '<div class="os-item__title">' + item.title + '</div>';
      if (variant) html += '<div class="os-item__variant">' + variant + '</div>';
      html += '</div>';
      html += '<div class="os-item__price">' + fmt(item.final_line_price) + '</div>';
      html += '</div>';
    });
    $('os-items').innerHTML = html;

    // Totals
    $('os-subtotal').textContent = fmt(cart.total_price);
    $('os-total').textContent = fmt(cart.total_price);
    $('os-bar-total').textContent = fmt(cart.total_price);
  }

  /* =========================================
     TOGGLE ORDER SUMMARY
     ========================================= */
  window.WC = window.WC || {};

  WC.toggleSummary = function () {
    var bar = $('os-bar');
    var content = $('os-content');
    bar.classList.toggle('open');
    content.classList.toggle('open');
  };

  /* =========================================
     ADDRESS AUTOCOMPLETE (Google Places)
     ========================================= */
  function initAddressAutocomplete() {
    var addressInput = $('co-address');
    if (!addressInput) return;

    function setup() {
      var countrySelect = $('co-country');
      var selectedCountry = countrySelect ? countrySelect.value.toLowerCase() : '';

      var ac = new google.maps.places.Autocomplete(addressInput, {
        types: ['address'],
        fields: ['address_components'],
        componentRestrictions: selectedCountry ? { country: selectedCountry } : undefined
      });

      // Prevent form submit on Enter while dropdown is visible
      addressInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          var pac = document.querySelector('.pac-container');
          if (pac && pac.offsetParent !== null) e.preventDefault();
        }
      });

      ac.addListener('place_changed', function () {
        var place = ac.getPlace();
        if (!place || !place.address_components) return;

        var comp = {};
        place.address_components.forEach(function (c) {
          var t = c.types[0];
          if (t === 'street_number')        comp.num = c.long_name;
          if (t === 'route')                comp.route = c.long_name;
          if (t === 'locality')             comp.city = c.long_name;
          if (t === 'postal_town' && !comp.city) comp.city = c.long_name;
          if (t === 'sublocality_level_1' && !comp.city) comp.city = c.long_name;
          if (t === 'administrative_area_level_1' && !comp.city) comp.city = c.long_name;
          if (t === 'postal_code')          comp.postal = c.long_name;
          if (t === 'country')              comp.country = c.short_name;
        });

        // Build street address
        var street = comp.route || '';
        if (comp.num) street = street ? (street + ' ' + comp.num) : comp.num;

        // Close dropdown immediately — blur before setting value
        addressInput.blur();
        var pacEl = document.querySelector('.pac-container');
        if (pacEl) pacEl.style.display = 'none';

        if (street) {
          addressInput.value = street;
        }

        var cityInput = $('co-city');
        if (cityInput && comp.city) {
          cityInput.value = comp.city;
        }

        var postalInput = $('co-postal');
        if (postalInput && comp.postal) {
          postalInput.value = comp.postal;
        }

        // Match country to dropdown option
        if (countrySelect && comp.country) {
          for (var i = 0; i < countrySelect.options.length; i++) {
            if (countrySelect.options[i].value === comp.country) {
              countrySelect.value = comp.country;
              break;
            }
          }
        }

        // Move to apartment field
        var aptInput = $('co-apartment');
        if (aptInput) setTimeout(function () { aptInput.focus(); }, 50);
      });

      // Update restriction when country dropdown changes
      if (countrySelect) {
        countrySelect.addEventListener('change', function () {
          ac.setComponentRestrictions({ country: this.value.toLowerCase() });
        });
      }
    }

    // Wait for Google Maps API (loaded async)
    if (typeof google !== 'undefined' && google.maps && google.maps.places) {
      setup();
    } else {
      var attempts = 0;
      var waitInterval = setInterval(function () {
        attempts++;
        if (typeof google !== 'undefined' && google.maps && google.maps.places) {
          clearInterval(waitInterval);
          setup();
        } else if (attempts > 100) {
          clearInterval(waitInterval);
        }
      }, 100);
    }
  }

  /* =========================================
     FORM VALIDATION
     ========================================= */
  function validate() {
    var fields = [
      { id: 'co-email', name: 'Email' },
      { id: 'co-last', name: 'Last name' },
      { id: 'co-address', name: 'Address' },
      { id: 'co-postal', name: 'Postal code' },
      { id: 'co-city', name: 'City' }
    ];
    var ok = true;

    // Clear previous errors
    document.querySelectorAll('.field--error').forEach(function (el) {
      el.classList.remove('field--error');
    });

    fields.forEach(function (f) {
      var input = $(f.id);
      if (!input) return;
      var val = input.value.trim();
      if (!val) {
        input.classList.add('field--error');
        ok = false;
      }
    });

    // Email format
    var email = $('co-email');
    if (email && email.value.trim()) {
      var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!re.test(email.value.trim())) {
        email.classList.add('field--error');
        ok = false;
      }
    }

    return ok;
  }

  /* =========================================
     SUBMIT → CREATE ORDER + WISE LINK → REDIRECT
     ========================================= */
  WC.submit = function () {
    if (!validate()) {
      var err = document.querySelector('.field--error');
      if (err) err.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    var btn = $('co-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="co-btn__spinner"></span>Processing…';

    var amount = (cart.total_price / 100).toFixed(2);

    // Collect form data
    var email     = $('co-email') ? $('co-email').value.trim() : '';
    var firstName = $('co-first') ? $('co-first').value.trim() : '';
    var lastName  = $('co-last')  ? $('co-last').value.trim()  : '';
    var address   = $('co-address') ? $('co-address').value.trim() : '';
    var apartment = $('co-apartment') ? $('co-apartment').value.trim() : '';
    var city      = $('co-city')    ? $('co-city').value.trim()    : '';
    var postal    = $('co-postal')  ? $('co-postal').value.trim()  : '';
    var country   = $('co-country') ? $('co-country').value        : 'DE';

    // Build cart items for Shopify Draft Order
    var cartItems = cart.items.map(function (item) {
      return {
        variant_id: item.variant_id,
        quantity: item.quantity,
        title: item.title,
        price: (item.final_line_price / 100 / item.quantity).toFixed(2)
      };
    });

    // Extract Shopify cart token from cookie for server-side verification
    var cartToken = '';
    try {
      var m = document.cookie.match(/cart=([^;]+)/);
      if (m) cartToken = decodeURIComponent(m[1]);
    } catch(e) {}

    var requestBody = {
      amount: parseFloat(amount),
      currency: 'EUR',
      email: email,
      firstName: firstName,
      lastName: lastName,
      address: address,
      apartment: apartment,
      city: city,
      postal: postal,
      country: country,
      cartItems: cartItems,
      cartToken: cartToken
    };

    // Sign request with HMAC then send
    signRequest(requestBody)
      .then(function (sig) {
        return fetch(SERVER + '/create-order', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Signature': sig.signature,
            'X-Timestamp': sig.timestamp
          },
          body: JSON.stringify(requestBody)
        });
      })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.link) {
          window.location.href = data.link;
        } else {
          throw new Error(data.error || 'Failed to create payment link');
        }
      })
      .catch(function (err) {
        console.error('Wise checkout error:', err);
        btn.disabled = false;
        btn.textContent = 'Review order';
        var msg = err.message || 'Payment error. Please try again.';
        var errBox = $('co-error');
        if (errBox) {
          errBox.textContent = msg;
          errBox.style.display = 'block';
          errBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
          alert(msg);
        }
      });
  };

  /* =========================================
     INIT — LOAD CART
     ========================================= */
  function init() {
    fetch('/cart.js', { credentials: 'same-origin' })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        cart = data;
        $('co-loading').style.display = 'none';

        if (!cart.items.length) {
          $('co-empty').style.display = 'block';
          return;
        }

        $('co-page').style.display = 'block';
        renderSummary();
        initAddressAutocomplete();
      })
      .catch(function (err) {
        console.error('Cart load error:', err);
        $('co-loading').style.display = 'none';
        $('co-empty').style.display = 'block';
      });
  }

  // Remove error styling on focus
  document.addEventListener('focusin', function (e) {
    if (e.target.classList && e.target.classList.contains('field--error')) {
      e.target.classList.remove('field--error');
    }
  });

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
