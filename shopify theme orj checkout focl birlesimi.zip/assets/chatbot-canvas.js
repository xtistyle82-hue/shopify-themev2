/**
 * Chatbot Canvas Effects
 * HTML5 Canvas powered animations for enhanced UX
 */

(function() {
  'use strict';

  // Canvas instances
  let bgCanvas, bgCtx;
  let particleCanvas, particleCtx;
  let avatarCanvas, avatarCtx;
  
  // Animation state
  let animationId = null;
  let particles = [];
  let mouseX = 0, mouseY = 0;

  // Avatar state
  let avatarState = {
    eyeOpen: 1,
    blinkTimer: 0,
    mouthOpen: 0,
    mood: 'neutral', // neutral, happy, thinking, sad, excited, love, sleepy, surprised
    thinkingDots: 0,
    // New advanced states
    pupilX: 0,
    pupilY: 0,
    targetPupilX: 0,
    targetPupilY: 0,
    eyebrowRaise: 0,
    blushOpacity: 0,
    breathePhase: 0,
    bounceY: 0,
    sparkleAngle: 0,
    heartBeat: 0,
    sweatDrop: 0,
    exclamation: 0,
    zzz: 0
  };

  // Wave state for background
  let waveOffset = 0;

  /**
   * Initialize all canvas elements
   */
  function initCanvasEffects() {
    const container = document.getElementById('chatbot-drawer');
    if (!container) return;

    // Create background canvas (interactive waves)
    bgCanvas = document.createElement('canvas');
    bgCanvas.id = 'chatbot-bg-canvas';
    bgCanvas.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;opacity:0.15;z-index:0;';
    container.insertBefore(bgCanvas, container.firstChild);

    // Create particle canvas (effects overlay)
    particleCanvas = document.createElement('canvas');
    particleCanvas.id = 'chatbot-particle-canvas';
    particleCanvas.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:100;';
    container.appendChild(particleCanvas);

    // Setup contexts
    bgCtx = bgCanvas.getContext('2d');
    particleCtx = particleCanvas.getContext('2d');

    // Resize canvases
    resizeCanvases();
    window.addEventListener('resize', resizeCanvases);

    // Track mouse for interactive background
    container.addEventListener('mousemove', (e) => {
      const rect = container.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    });

    // Start animation loop
    startAnimationLoop();

    // Setup avatar canvas in header
    setupAvatarCanvas();

    console.log('Canvas effects initialized');
  }

  /**
   * Resize all canvases to match container
   */
  function resizeCanvases() {
    const container = document.getElementById('chatbot-drawer');
    if (!container) return;

    const width = container.offsetWidth;
    const height = container.offsetHeight;
    const dpr = window.devicePixelRatio || 1;

    [bgCanvas, particleCanvas].forEach(canvas => {
      if (canvas) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
        const ctx = canvas.getContext('2d');
        ctx.scale(dpr, dpr);
      }
    });
  }

  /**
   * Setup animated avatar canvas
   */
  function setupAvatarCanvas() {
    const avatarContainer = document.querySelector('.chatbot-header__avatar');
    if (!avatarContainer) return;

    // Clear existing content
    avatarContainer.innerHTML = '';

    avatarCanvas = document.createElement('canvas');
    avatarCanvas.width = 80;
    avatarCanvas.height = 80;
    avatarCanvas.style.cssText = 'width:40px;height:40px;';
    avatarContainer.appendChild(avatarCanvas);
    avatarCtx = avatarCanvas.getContext('2d');
  }

  /**
   * Main animation loop
   */
  function startAnimationLoop() {
    function animate() {
      animationId = requestAnimationFrame(animate);
      
      // Draw background waves
      drawBackgroundWaves();
      
      // Update and draw particles
      updateParticles();
      drawParticles();
      
      // Animate avatar
      animateAvatar();
    }
    animate();
  }

  /**
   * Draw interactive background waves
   */
  function drawBackgroundWaves() {
    if (!bgCtx || !bgCanvas) return;

    const width = bgCanvas.width / (window.devicePixelRatio || 1);
    const height = bgCanvas.height / (window.devicePixelRatio || 1);

    bgCtx.clearRect(0, 0, width, height);

    // Wave parameters
    waveOffset += 0.02;
    const waveCount = 3;
    const colors = ['rgba(0,0,0,0.1)', 'rgba(50,50,50,0.08)', 'rgba(100,100,100,0.05)'];

    for (let w = 0; w < waveCount; w++) {
      bgCtx.beginPath();
      bgCtx.moveTo(0, height);

      for (let x = 0; x <= width; x += 5) {
        // Mouse influence
        const dx = x - mouseX;
        const dy = height * 0.7 - mouseY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const mouseInfluence = Math.max(0, 1 - dist / 200) * 30;

        const y = height * 0.7 
          + Math.sin(x * 0.01 + waveOffset + w * 0.5) * 20 
          + Math.sin(x * 0.02 + waveOffset * 1.5 + w) * 10
          - mouseInfluence;
        
        bgCtx.lineTo(x, y);
      }

      bgCtx.lineTo(width, height);
      bgCtx.closePath();
      bgCtx.fillStyle = colors[w];
      bgCtx.fill();
    }
  }

  /**
   * Animate the avatar with advanced features
   */
  function animateAvatar() {
    if (!avatarCtx || !avatarCanvas) return;

    const size = 80;
    const cx = 40, cy = 40;
    avatarCtx.clearRect(0, 0, size, size);

    // Update animation timers
    avatarState.breathePhase += 0.05;
    avatarState.sparkleAngle += 0.1;
    
    // Smooth pupil movement
    avatarState.pupilX += (avatarState.targetPupilX - avatarState.pupilX) * 0.1;
    avatarState.pupilY += (avatarState.targetPupilY - avatarState.pupilY) * 0.1;

    // Bounce effect for excited mood
    if (avatarState.mood === 'excited') {
      avatarState.bounceY = Math.sin(avatarState.breathePhase * 3) * 3;
    } else {
      avatarState.bounceY *= 0.9;
    }

    // Breathing effect - subtle scale
    const breatheScale = 1 + Math.sin(avatarState.breathePhase) * 0.02;

    avatarCtx.save();
    avatarCtx.translate(cx, cy + avatarState.bounceY);
    avatarCtx.scale(breatheScale, breatheScale);
    avatarCtx.translate(-cx, -cy);

    // Background circle with gradient
    const gradient = avatarCtx.createRadialGradient(35, 35, 0, 40, 40, 38);
    gradient.addColorStop(0, '#333');
    gradient.addColorStop(1, '#000');
    avatarCtx.beginPath();
    avatarCtx.arc(cx, cy, 35, 0, Math.PI * 2);
    avatarCtx.fillStyle = gradient;
    avatarCtx.fill();

    // Blush cheeks (for happy/love moods)
    if (avatarState.mood === 'happy' || avatarState.mood === 'love') {
      avatarState.blushOpacity = Math.min(1, avatarState.blushOpacity + 0.05);
    } else {
      avatarState.blushOpacity = Math.max(0, avatarState.blushOpacity - 0.05);
    }
    if (avatarState.blushOpacity > 0) {
      avatarCtx.globalAlpha = avatarState.blushOpacity * 0.4;
      avatarCtx.fillStyle = '#ff6b6b';
      avatarCtx.beginPath();
      avatarCtx.ellipse(20, 45, 8, 5, 0, 0, Math.PI * 2);
      avatarCtx.fill();
      avatarCtx.beginPath();
      avatarCtx.ellipse(60, 45, 8, 5, 0, 0, Math.PI * 2);
      avatarCtx.fill();
      avatarCtx.globalAlpha = 1;
    }

    // Eyebrows
    avatarCtx.strokeStyle = '#fff';
    avatarCtx.lineWidth = 2;
    avatarCtx.lineCap = 'round';
    
    let leftBrowY = 24, rightBrowY = 24;
    let leftBrowAngle = 0, rightBrowAngle = 0;
    
    if (avatarState.mood === 'sad') {
      leftBrowAngle = 0.3; rightBrowAngle = -0.3;
      leftBrowY = 26; rightBrowY = 26;
    } else if (avatarState.mood === 'surprised' || avatarState.mood === 'excited') {
      leftBrowY = 20; rightBrowY = 20;
      avatarState.eyebrowRaise = Math.sin(avatarState.breathePhase * 2) * 2;
      leftBrowY += avatarState.eyebrowRaise;
      rightBrowY += avatarState.eyebrowRaise;
    } else if (avatarState.mood === 'thinking') {
      leftBrowAngle = 0.2;
      leftBrowY = 22;
    }

    // Draw eyebrows
    avatarCtx.save();
    avatarCtx.translate(28, leftBrowY);
    avatarCtx.rotate(leftBrowAngle);
    avatarCtx.beginPath();
    avatarCtx.moveTo(-8, 0);
    avatarCtx.lineTo(8, 0);
    avatarCtx.stroke();
    avatarCtx.restore();

    avatarCtx.save();
    avatarCtx.translate(52, rightBrowY);
    avatarCtx.rotate(rightBrowAngle);
    avatarCtx.beginPath();
    avatarCtx.moveTo(-8, 0);
    avatarCtx.lineTo(8, 0);
    avatarCtx.stroke();
    avatarCtx.restore();

    // Eyes - Blinking logic
    avatarState.blinkTimer++;
    if (avatarState.mood === 'sleepy') {
      avatarState.eyeOpen = 0.3 + Math.sin(avatarState.breathePhase * 0.5) * 0.2;
    } else if (avatarState.blinkTimer > 120 + Math.random() * 60) {
      avatarState.eyeOpen = Math.max(0, avatarState.eyeOpen - 0.25);
      if (avatarState.eyeOpen <= 0) {
        avatarState.blinkTimer = 0;
        avatarState.eyeOpen = 1;
      }
    }

    const eyeHeight = avatarState.mood === 'surprised' ? 10 : 8;
    const eyeWidth = avatarState.mood === 'surprised' ? 8 : 6;
    const actualEyeHeight = eyeHeight * avatarState.eyeOpen;

    avatarCtx.fillStyle = '#fff';

    // Left eye white
    avatarCtx.beginPath();
    avatarCtx.ellipse(28, 35, eyeWidth, actualEyeHeight, 0, 0, Math.PI * 2);
    avatarCtx.fill();

    // Right eye white
    avatarCtx.beginPath();
    avatarCtx.ellipse(52, 35, eyeWidth, actualEyeHeight, 0, 0, Math.PI * 2);
    avatarCtx.fill();

    // Pupils with movement
    if (avatarState.eyeOpen > 0.3) {
      avatarCtx.fillStyle = '#000';
      const pupilSize = avatarState.mood === 'love' ? 2 : (avatarState.mood === 'surprised' ? 4 : 3);
      
      // Love mood - heart eyes
      if (avatarState.mood === 'love') {
        avatarCtx.fillStyle = '#ff4757';
        drawHeart(avatarCtx, 28 + avatarState.pupilX, 35 + avatarState.pupilY, 6);
        drawHeart(avatarCtx, 52 + avatarState.pupilX, 35 + avatarState.pupilY, 6);
      } else {
        // Normal pupils
        avatarCtx.beginPath();
        avatarCtx.arc(28 + avatarState.pupilX * 2, 35 + avatarState.pupilY, pupilSize, 0, Math.PI * 2);
        avatarCtx.fill();
        avatarCtx.beginPath();
        avatarCtx.arc(52 + avatarState.pupilX * 2, 35 + avatarState.pupilY, pupilSize, 0, Math.PI * 2);
        avatarCtx.fill();

        // Eye shine
        avatarCtx.fillStyle = 'rgba(255,255,255,0.8)';
        avatarCtx.beginPath();
        avatarCtx.arc(26 + avatarState.pupilX, 33, 1.5, 0, Math.PI * 2);
        avatarCtx.fill();
        avatarCtx.beginPath();
        avatarCtx.arc(50 + avatarState.pupilX, 33, 1.5, 0, Math.PI * 2);
        avatarCtx.fill();
      }
    }

    // Mouth based on mood
    avatarCtx.strokeStyle = '#fff';
    avatarCtx.fillStyle = '#fff';
    avatarCtx.lineWidth = 3;
    avatarCtx.lineCap = 'round';

    if (avatarState.mood === 'happy' || avatarState.mood === 'love') {
      // Big smile
      avatarCtx.beginPath();
      avatarCtx.arc(cx, 50, 12, 0.1 * Math.PI, 0.9 * Math.PI);
      avatarCtx.stroke();
      // Teeth
      avatarCtx.fillStyle = '#fff';
      avatarCtx.fillRect(34, 50, 12, 4);
    } else if (avatarState.mood === 'excited') {
      // Open mouth smile
      avatarCtx.beginPath();
      avatarCtx.ellipse(cx, 52, 10, 8, 0, 0, Math.PI * 2);
      avatarCtx.fillStyle = '#ff6b6b';
      avatarCtx.fill();
      avatarCtx.fillStyle = '#fff';
      avatarCtx.fillRect(34, 48, 12, 4);
    } else if (avatarState.mood === 'sad') {
      // Frown
      avatarCtx.beginPath();
      avatarCtx.arc(cx, 60, 10, 1.2 * Math.PI, 1.8 * Math.PI);
      avatarCtx.stroke();
    } else if (avatarState.mood === 'surprised') {
      // O mouth
      avatarCtx.beginPath();
      avatarCtx.ellipse(cx, 54, 6, 8, 0, 0, Math.PI * 2);
      avatarCtx.stroke();
    } else if (avatarState.mood === 'thinking') {
      // Animated thinking dots
      avatarState.thinkingDots = (avatarState.thinkingDots + 0.08) % 4;
      for (let i = 0; i < 3; i++) {
        const bounce = i <= avatarState.thinkingDots ? Math.sin((avatarState.breathePhase + i) * 3) * 2 : 0;
        avatarCtx.globalAlpha = i <= avatarState.thinkingDots ? 1 : 0.3;
        avatarCtx.beginPath();
        avatarCtx.arc(30 + i * 10, 54 - bounce, 3, 0, Math.PI * 2);
        avatarCtx.fill();
      }
      avatarCtx.globalAlpha = 1;
    } else if (avatarState.mood === 'sleepy') {
      // Wavy sleepy mouth
      avatarCtx.beginPath();
      avatarCtx.moveTo(32, 54);
      avatarCtx.quadraticCurveTo(40, 52 + Math.sin(avatarState.breathePhase) * 2, 48, 54);
      avatarCtx.stroke();
    } else {
      // Neutral - small smile
      avatarCtx.beginPath();
      avatarCtx.arc(cx, 52, 8, 0.1 * Math.PI, 0.9 * Math.PI);
      avatarCtx.stroke();
    }

    avatarCtx.restore();

    // Extra effects outside the face
    // Sparkles for excited/love mood
    if (avatarState.mood === 'excited' || avatarState.mood === 'love') {
      drawSparkles(avatarCtx, cx, cy, avatarState.sparkleAngle);
    }

    // ZZZ for sleepy
    if (avatarState.mood === 'sleepy') {
      avatarState.zzz = (avatarState.zzz + 0.02) % 1;
      avatarCtx.fillStyle = '#fff';
      avatarCtx.font = '10px Arial';
      const zAlpha = 1 - avatarState.zzz;
      avatarCtx.globalAlpha = zAlpha;
      avatarCtx.fillText('Z', 60 + avatarState.zzz * 10, 20 - avatarState.zzz * 15);
      avatarCtx.font = '8px Arial';
      avatarCtx.fillText('z', 65 + avatarState.zzz * 8, 25 - avatarState.zzz * 10);
      avatarCtx.globalAlpha = 1;
    }

    // Sweat drop for confused/thinking
    if (avatarState.mood === 'thinking') {
      avatarState.sweatDrop = (avatarState.sweatDrop + 0.03) % 1;
      avatarCtx.fillStyle = '#87CEEB';
      avatarCtx.globalAlpha = 1 - avatarState.sweatDrop;
      avatarCtx.beginPath();
      avatarCtx.moveTo(65, 20 + avatarState.sweatDrop * 15);
      avatarCtx.quadraticCurveTo(68, 25 + avatarState.sweatDrop * 15, 65, 30 + avatarState.sweatDrop * 15);
      avatarCtx.quadraticCurveTo(62, 25 + avatarState.sweatDrop * 15, 65, 20 + avatarState.sweatDrop * 15);
      avatarCtx.fill();
      avatarCtx.globalAlpha = 1;
    }
  }

  /**
   * Draw a heart shape
   */
  function drawHeart(ctx, x, y, size) {
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.moveTo(0, size * 0.3);
    ctx.bezierCurveTo(-size * 0.5, -size * 0.3, -size, size * 0.3, 0, size);
    ctx.bezierCurveTo(size, size * 0.3, size * 0.5, -size * 0.3, 0, size * 0.3);
    ctx.fill();
    ctx.restore();
  }

  /**
   * Draw sparkle effects around avatar
   */
  function drawSparkles(ctx, cx, cy, angle) {
    ctx.fillStyle = '#FFD700';
    for (let i = 0; i < 4; i++) {
      const a = angle + (Math.PI / 2) * i;
      const dist = 38 + Math.sin(angle * 2 + i) * 5;
      const x = cx + Math.cos(a) * dist;
      const y = cy + Math.sin(a) * dist;
      const sparkleSize = 2 + Math.sin(angle * 3 + i) * 1;
      
      ctx.globalAlpha = 0.5 + Math.sin(angle * 2 + i) * 0.5;
      ctx.beginPath();
      // 4-point star
      ctx.moveTo(x, y - sparkleSize);
      ctx.lineTo(x + sparkleSize * 0.3, y);
      ctx.lineTo(x, y + sparkleSize);
      ctx.lineTo(x - sparkleSize * 0.3, y);
      ctx.closePath();
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(x - sparkleSize, y);
      ctx.lineTo(x, y + sparkleSize * 0.3);
      ctx.lineTo(x + sparkleSize, y);
      ctx.lineTo(x, y - sparkleSize * 0.3);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  /**
   * Set avatar mood
   */
  function setAvatarMood(mood) {
    avatarState.mood = mood;
  }

  /**
   * Create particles
   */
  function createParticles(x, y, count, type = 'sparkle') {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 / count) * i + Math.random() * 0.5;
      const speed = type === 'confetti' ? 3 + Math.random() * 5 : 1 + Math.random() * 2;
      
      particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (type === 'confetti' ? 5 : 0),
        life: 1,
        decay: 0.02 + Math.random() * 0.02,
        size: type === 'confetti' ? 4 + Math.random() * 4 : 2 + Math.random() * 3,
        type: type,
        color: type === 'confetti' 
          ? `hsl(${Math.random() * 360}, 80%, 60%)`
          : `rgba(255, 215, 0, ${0.8 + Math.random() * 0.2})`,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.2
      });
    }
  }

  /**
   * Update particles
   */
  function updateParticles() {
    particles = particles.filter(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.type === 'confetti' ? 0.2 : 0.05; // gravity
      p.life -= p.decay;
      p.rotation += p.rotationSpeed || 0;
      return p.life > 0;
    });
  }

  /**
   * Draw particles
   */
  function drawParticles() {
    if (!particleCtx || !particleCanvas) return;

    const width = particleCanvas.width / (window.devicePixelRatio || 1);
    const height = particleCanvas.height / (window.devicePixelRatio || 1);

    particleCtx.clearRect(0, 0, width, height);

    particles.forEach(p => {
      particleCtx.save();
      particleCtx.translate(p.x, p.y);
      particleCtx.rotate(p.rotation || 0);
      particleCtx.globalAlpha = p.life;

      if (p.type === 'confetti') {
        particleCtx.fillStyle = p.color;
        particleCtx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      } else {
        // Sparkle
        particleCtx.fillStyle = p.color;
        particleCtx.beginPath();
        particleCtx.arc(0, 0, p.size * p.life, 0, Math.PI * 2);
        particleCtx.fill();
      }

      particleCtx.restore();
    });
  }

  /**
   * Trigger sparkle effect
   */
  function sparkle(x, y) {
    createParticles(x, y, 12, 'sparkle');
  }

  /**
   * Trigger confetti effect
   */
  function confetti() {
    const container = document.getElementById('chatbot-drawer');
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const centerX = rect.width / 2;

    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        createParticles(centerX + (Math.random() - 0.5) * 100, 100, 20, 'confetti');
      }, i * 100);
    }
  }

  /**
   * Sparkle on chatbot open
   */
  function onChatbotOpen() {
    const container = document.getElementById('chatbot-drawer');
    if (!container) return;

    const rect = container.getBoundingClientRect();
    // Sparkles from corners
    sparkle(50, 50);
    sparkle(rect.width - 50, 50);
    setTimeout(() => sparkle(rect.width / 2, rect.height / 2), 200);
  }

  // Expose API
  window.ChatbotCanvas = {
    init: initCanvasEffects,
    sparkle: sparkle,
    confetti: confetti,
    setMood: setAvatarMood,
    onOpen: onChatbotOpen
  };

  // Auto-init when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(initCanvasEffects, 100);
    });
  } else {
    setTimeout(initCanvasEffects, 100);
  }

})();
